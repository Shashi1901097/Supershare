package com.supershare.app

import android.Manifest
import android.app.RecoverableSecurityException
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Environment
import android.os.Bundle
import android.os.Handler
import android.os.PowerManager
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.supershare.app.core.Keys
import com.supershare.app.core.Progress
import com.supershare.app.core.Protocol
import com.supershare.app.core.Receiver
import com.supershare.app.core.ReceiverEvents
import com.supershare.app.core.Registry
import com.supershare.app.core.Sender
import java.io.File
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

const val PORT = 8988
const val REG_PORT = 8989

class DeviceInfo(val ip: String, val name: String, val port: Int)
class DevState(val progress: Float, val mbps: Float, val status: String)
class BrowseEntry(val path: String, val name: String, val dir: Boolean, val size: Long)

/** Opens the system file browser at Downloads (where ZIP, GZ, APK ... usually are) and shows every file type. */
class OpenDocsInDownloads : ActivityResultContracts.OpenMultipleDocuments() {
    override fun createIntent(context: Context, input: Array<String>): Intent {
        val i = super.createIntent(context, input)
        try {
            i.putExtra(DocumentsContract.EXTRA_INITIAL_URI,
                DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:Download"))
        } catch (e: Exception) { }
        return i
    }
}

class Meter {
    private var t0 = 0L
    private var base = 0L
    private var last = 0L
    fun update(d: Long, t: Long): DevState? {
        val now = System.nanoTime()
        if (t0 == 0L) { t0 = now; base = d }
        if (d < t && now - last < 200_000_000L) return null
        last = now
        val sec = (now - t0) / 1e9
        val mbps = if (sec > 0.3) ((d - base) * 8 / 1e6 / sec).toFloat() else 0f
        return DevState(if (t > 0) (d.toFloat() / t).coerceIn(0f, 1f) else 0f, mbps, "Sending…")
    }
}

class UiState {
    var screen by mutableStateOf("home")      // home, send, group, receive, join, files
    var prev by mutableStateOf("home")
    var status by mutableStateOf("")
    var message by mutableStateOf("")
    var code by mutableStateOf("")            // code shown on this phone
    var codeInput by mutableStateOf("")       // code typed to send to one phone
    var joinInput by mutableStateOf("")       // code typed to join a group
    var files by mutableStateOf<List<Item>>(emptyList())
    var blocked by mutableStateOf<Set<String>>(emptySet())
    var current by mutableStateOf("")
    var active by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var joined by mutableStateOf(false)
    var manage by mutableStateOf(false)
    var progress by mutableFloatStateOf(0f)
    var mbps by mutableFloatStateOf(0f)
    var peak by mutableFloatStateOf(0f)
    var eta by mutableLongStateOf(-1L)
    var done by mutableLongStateOf(0L)
    var total by mutableLongStateOf(0L)
    var free by mutableLongStateOf(0L)
    var spaceAlert by mutableStateOf("")
    var library by mutableStateOf<List<RFile>>(emptyList())
    var partials by mutableStateOf<List<Partial>>(emptyList())
    var allFiles by mutableStateOf(false)
    var browsePath by mutableStateOf("")
    var browseEntries by mutableStateOf<List<BrowseEntry>>(emptyList())
    var browseSel by mutableStateOf<Set<String>>(emptySet())
    var browseBack by mutableStateOf("send")
    var wifiOn by mutableStateOf(true)
    var prompt by mutableStateOf("")          // "", "wifi" or "location": asks the user to switch it on
    var recent by mutableStateOf<List<RFile>>(emptyList())   // files received in this session only
    var needLocation by mutableStateOf(false)
    var locationOn by mutableStateOf(true)
    var devices by mutableStateOf<List<DeviceInfo>>(emptyList())
    var deselected by mutableStateOf<Set<String>>(emptySet())
    val devState = mutableStateMapOf<String, DevState>()
    private var t0 = 0L
    private var base = 0L
    private var lastUi = 0L

    fun newBatch() { t0 = 0L; base = 0L; progress = 0f; mbps = 0f; eta = -1L }
    fun reset() {
        newBatch(); peak = 0f; status = ""; current = ""; active = false; joined = false
        done = 0; total = 0; spaceAlert = ""; blocked = emptySet(); busy = false
    }
    fun update(d: Long, t: Long) {
        val now = System.nanoTime()
        if (t0 == 0L) { t0 = now; base = d }
        if (d < t && now - lastUi < 100_000_000L) return      // keep the screen smooth
        lastUi = now
        active = true; done = d; total = t
        progress = if (t > 0) (d.toFloat() / t).coerceIn(0f, 1f) else 0f
        val sec = (now - t0) / 1e9
        if (sec > 0.3) {
            val bps = (d - base) / sec
            mbps = (bps * 8 / 1e6).toFloat()
            if (mbps > peak) peak = mbps
            eta = if (bps > 1) ((t - d) / bps).toLong() else -1L
        }
    }
}

class MainActivity : ComponentActivity() {
    private val ui = UiState()
    private lateinit var storage: AndroidStorage
    private var wd: WifiDirect? = null
    private var receiver: Receiver? = null
    private var registry: Registry? = null
    private var heartbeat: Thread? = null
    private var picked: List<Item> = emptyList()
    private val sending = AtomicBoolean(false)
    private val cancel = AtomicBoolean(false)
    private val groupRunning = AtomicInteger(0)
    private var groupCode = ""
    private var lastHost: String? = null
    private var lastCode: String = ""
    private var sessionStart = 0L
    private var pendingAction: (() -> Unit)? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    private val pickFiles = registerForActivityResult(OpenDocsInDownloads()) { uris: List<Uri> -> addPicked(uris) }
    private val pickMedia = registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris: List<Uri> -> addPicked(uris) }
    private val pickOther = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris: List<Uri> -> addPicked(uris) }
    private val deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        )
        storage = AndroidStorage(applicationContext)
        perms.launch(
            if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
            else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        )
        refresh()
        val actions = Actions(
            onReceive = { guard { startReceive() } },
            onSend = { guard { stopAll(); ui.reset(); ui.files = picked; ui.prev = "home"; ui.screen = "send" } },
            onGroup = { guard { startGroup() } },
            onJoinMode = { stopAll(); ui.reset(); ui.screen = "join" },
            onJoin = { guard { joinGroup() } },
            onPick = { pickFiles.launch(arrayOf("*/*")) },
            onPickMedia = { pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) },
            onPickOther = { pickOther.launch("*/*") },
            onClear = { picked = emptyList(); ui.files = emptyList(); ui.blocked = emptySet() },
            onBrowse = { openBrowser() },
            onBrowseOpen = { loadDir(it) },
            onBrowseUp = { browseUp() },
            onBrowseToggle = { p -> ui.browseSel = if (p in ui.browseSel) ui.browseSel - p else ui.browseSel + p },
            onBrowseAll = { ui.browseSel = ui.browseSel + ui.browseEntries.filter { !it.dir }.map { it.path } },
            onBrowseFolder = { browseFolder(ui.browsePath) },
            onBrowseDone = { browseDone() },
            onAllFilesAccess = { requestAllFiles() },
            onStartSend = { guard { startSend() } },
            onSendGroup = { sendGroup() },
            onToggleDevice = { ip -> ui.deselected = if (ip in ui.deselected) ui.deselected - ip else ui.deselected + ip },
            onStop = { cancel.set(true) },
            onBack = { back() },
            onFiles = { refresh(); ui.manage = false; ui.prev = ui.screen; ui.screen = "files" },
            onManage = { refresh(); ui.manage = true; ui.prev = ui.screen; ui.screen = "files" },
            onOpen = { openFile(it) },
            onDelete = { deleteFile(it) },
            onDiscard = { Library.discard(this, it); refresh() },
            onStorageSettings = { openStorageSettings() },
            onWifi = { openWifiPanel() },
            onLocation = { openSettings(Settings.ACTION_LOCATION_SOURCE_SETTINGS) },
            onDismissPrompt = { pendingAction = null; ui.prompt = "" },
            onRefresh = { refresh(); checkPending() }
        )
        setContent { SuperTheme { AppScreen(ui, actions) } }
    }

    override fun onResume() {
        super.onResume()
        refresh()
        checkPending()
    }

    // ---------------- Wi-Fi / Location must be on ----------------
    /** "" when everything needed is on, otherwise what to ask for. */
    private fun needed(): String = when {
        !ui.wifiOn -> "wifi"
        ui.needLocation && !ui.locationOn -> "location"
        else -> ""
    }

    /** Runs [action] now, or shows the "please turn on Wi-Fi" popup and runs it as soon as Wi-Fi is on. */
    private fun guard(action: () -> Unit) {
        refreshStatus()
        val need = needed()
        if (need.isEmpty()) { action(); return }
        pendingAction = action
        ui.prompt = need
    }

    private fun checkPending() {
        val p = pendingAction ?: return
        val need = needed()
        if (need.isEmpty()) { pendingAction = null; ui.prompt = ""; p() } else ui.prompt = need
    }

    // ---------------- status ----------------
    private fun refreshStatus() {
        ui.free = freeSpace(applicationContext)
        ui.allFiles = hasAllFiles()
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            ui.wifiOn = wm.isWifiEnabled
        } catch (e: Exception) { }
        if (Build.VERSION.SDK_INT < 33) {
            ui.needLocation = true
            try { ui.locationOn = (getSystemService(Context.LOCATION_SERVICE) as LocationManager).isLocationEnabled }
            catch (e: Exception) { }
        } else ui.needLocation = false
    }

    private fun refresh() {
        refreshStatus()
        val s = ui.screen
        if (s == "receive" || s == "join" || s == "files") {
            ui.library = Library.list(applicationContext)
            ui.partials = Library.partials(applicationContext)
            ui.recent = ui.library.filter { it.added >= sessionStart }
        }
        val reg = registry
        if (reg != null) ui.devices = reg.devices().map { DeviceInfo(it.ip, it.name, it.port) }
    }

    private fun back() {
        if (ui.screen == "files") { ui.screen = ui.prev; return }
        if (ui.screen == "browse") { ui.screen = ui.browseBack; return }
        stopAll(); ui.screen = "home"
    }

    /** Android does not let an app switch Wi-Fi / Bluetooth on by itself, so these open the system panel. */
    private fun openWifiPanel() {
        try { startActivity(Intent(Settings.Panel.ACTION_WIFI)) }
        catch (e: Exception) { openSettings(Settings.ACTION_WIFI_SETTINGS) }
    }

    private fun openSettings(action: String) {
        try { startActivity(Intent(action)) } catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) { } }
    }

    /** Keep Wi-Fi at full performance and the CPU/screen awake while transferring. */
    private fun boost() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (wifiLock == null) wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "SuperShare").apply { acquire() }
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock == null) wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SuperShare:xfer").apply { acquire(60 * 60 * 1000L) }
        } catch (e: Exception) { }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun deviceName(): String {
        val n = try { Settings.Global.getString(contentResolver, "device_name") } catch (e: Exception) { null }
        return n?.takeIf { it.isNotBlank() } ?: Build.MODEL
    }

    // ---------------- browse ALL files on the phone (needs "access to all files") ----------------
    private fun hasAllFiles(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestAllFiles() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) { openSettings(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION) }
        } else perms.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE))
    }

    @Suppress("DEPRECATION")
    private fun storageRoot(): String = Environment.getExternalStorageDirectory().absolutePath

    private fun openBrowser() {
        if (!hasAllFiles()) {
            ui.message = "Turn on \"Allow access to all files\" for Super Share, then come back and tap Browse again."
            requestAllFiles()
            return
        }
        if (ui.screen != "browse") ui.browseBack = ui.screen
        ui.browseSel = emptySet()
        ui.screen = "browse"
        loadDir(storageRoot())
    }

    private fun loadDir(path: String) {
        val list = try { File(path).listFiles() } catch (e: SecurityException) { null }
        if (list == null) { ui.message = "Cannot open this folder"; return }
        ui.browsePath = path
        ui.browseEntries = list.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))
            .map { BrowseEntry(it.absolutePath, it.name, it.isDirectory, if (it.isDirectory) 0L else it.length()) }
    }

    private fun browseUp() {
        val parent = File(ui.browsePath).parentFile
        if (ui.browsePath != storageRoot() && parent != null) loadDir(parent.absolutePath) else ui.screen = ui.browseBack
    }

    private fun addFiles(files: List<File>) {
        val items = files.map { Item(Uri.fromFile(it), it.name, it.length(), Protocol.fileId(it.name, it.length(), it.lastModified())) }
        val known = picked.map { it.id }.toSet()
        picked = picked + items.filter { it.id !in known }
        ui.files = picked
        ui.blocked = emptySet()
    }

    private fun browseDone() {
        addFiles(ui.browseSel.map { File(it) }.filter { it.isFile && it.canRead() })
        ui.screen = ui.browseBack
    }

    private fun browseFolder(path: String) {
        val out = ArrayList<File>()
        fun walk(d: File, depth: Int) {
            if (depth > 8) return
            val kids = d.listFiles() ?: return
            for (k in kids) {
                if (out.size >= 2000) return
                if (k.isDirectory) walk(k, depth + 1) else if (k.canRead()) out.add(k)
            }
        }
        walk(File(path), 0)
        addFiles(out)
        ui.message = "Added ${out.size} file(s) from this folder"
        ui.screen = ui.browseBack
    }

    // ---------------- choosing files ----------------
    private fun addPicked(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val items = resolveItems(this, uris)
        if (items.isEmpty()) { ui.message = "Could not read the selected file(s)"; return }
        val known = picked.map { it.id }.toSet()
        picked = picked + items.filter { it.id !in known }
        ui.files = picked
        ui.blocked = emptySet()
    }

    // ---------------- receiving (show my code) ----------------
    private fun makeEvents() = object : ReceiverEvents {
        override fun onBatch(done: Long, total: Long, blocked: Int, maxNeedMore: Long, firstBlockedName: String) {
            ui.newBatch()
            ui.spaceAlert = if (blocked > 0)
                "Not enough storage for \"$firstBlockedName\"" +
                    (if (blocked > 1) " and ${blocked - 1} more" else "") +
                    ". Free up ${fmtSize(maxNeedMore)} to continue."
            else ""
            refresh()
        }
        override fun onProgress(done: Long, total: Long) { ui.update(done, total) }
        override fun onFileStart(name: String) { ui.current = name }
        override fun onFileDone(name: String) { ui.status = "Received: $name"; refresh() }
        override fun onAuthFailed(totalFailures: Int) { ui.status = "A device tried a wrong code ($totalFailures)" }
    }

    private fun startReceive() {
        stopAll(); ui.reset(); ui.screen = "receive"; boost()
        sessionStart = System.currentTimeMillis() / 1000 - 1; ui.recent = emptyList()
        val code = Keys.newCode()
        ui.code = Keys.pretty(code)
        ui.status = "Preparing a secure link…"
        refresh()
        Thread {
            try {
                val k = Keys.derive(code)
                runOnUiThread {
                    if (ui.screen != "receive" && ui.screen != "files") return@runOnUiThread
                    try {
                        val rx = Receiver(code, storage, makeEvents())
                        rx.start(PORT, null)
                        receiver = rx
                        wd = WifiDirect(this, {}, { ui.status = it }).also { it.host(k) }
                    } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
                }
            } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
        }.start()
    }

    // ---------------- receiving (join a group) ----------------
    private fun joinGroup() {
        val code = Keys.normalize(ui.joinInput)
        if (!Keys.isValid(code)) { ui.status = "Enter the sender's 6-digit code"; return }
        val typed = ui.joinInput
        stopAll(); ui.reset(); ui.screen = "join"; ui.joinInput = typed; boost()
        sessionStart = System.currentTimeMillis() / 1000 - 1; ui.recent = emptyList()
        ui.status = "Connecting to the sender…"
        Thread {
            try {
                val k = Keys.derive(code)
                runOnUiThread {
                    try {
                        val rx = Receiver(code, storage, makeEvents())
                        rx.start(PORT, null)
                        receiver = rx
                        val w = WifiDirect(this, { info -> onGroupJoined(info.groupOwnerAddress?.hostAddress) }, { ui.status = it })
                        wd = w
                        Handler(mainLooper).postDelayed({ w.join(k) }, 500)
                    } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
                }
            } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
        }.start()
    }

    private fun onGroupJoined(host: String?) {
        if (host == null || ui.joined) return
        ui.joined = true
        ui.status = "Connected. Waiting for the sender to start…"
        heartbeat?.interrupt()
        val name = deviceName()
        val t = Thread {
            while (!Thread.currentThread().isInterrupted) {
                try { Registry.register(host, REG_PORT, name, PORT) } catch (e: IOException) { }
                try { Thread.sleep(4000) } catch (e: InterruptedException) { break }
            }
        }
        t.isDaemon = true
        t.start()
        heartbeat = t
    }

    // ---------------- sending to one phone ----------------
    private fun startSend() {
        val code = Keys.normalize(ui.codeInput)
        if (picked.isEmpty()) { ui.status = "Choose the files to send first"; return }
        if (!Keys.isValid(code)) { ui.status = "Enter the receiver's 6-digit code"; return }
        boost(); cancel.set(false)
        val host = lastHost
        if (host != null && lastCode == code) { doSend(host, code); return }
        ui.status = "Connecting securely…"
        wd?.stop(); wd = null; sending.set(false)
        Thread {
            try {
                val k = Keys.derive(code)
                runOnUiThread {
                    val w = WifiDirect(this,
                        { info -> info.groupOwnerAddress?.hostAddress?.let { doSend(it, code) } },
                        { ui.status = it })
                    wd = w
                    Handler(mainLooper).postDelayed({ w.join(k) }, 700)
                }
            } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
        }.start()
    }

    private fun doSend(host: String, code: String) {
        if (!sending.compareAndSet(false, true)) return
        lastHost = host
        lastCode = code
        cancel.set(false)
        val items = picked
        ui.busy = true
        Thread {
            val sources = items.map { AndroidSource(applicationContext, it) }
            var failures = 0
            var waited = 0L
            var failure: Exception? = null
            try {
                while (!cancel.get()) {
                    try {
                        ui.status = "Sending…"
                        val r = Sender.send(host, PORT, code, sources, Progress { d, t -> ui.update(d, t) }, cancel)
                        failures = 0
                        if (r.complete) {
                            ui.blocked = emptySet()
                            ui.status = "Done ✓ ${items.size} file(s)" +
                                (if (r.haveCount > 0) " (${r.haveCount} already on the receiver)" else "")
                            break
                        }
                        ui.blocked = r.blockedIds.toSet()
                        ui.status = "Receiver has insufficient storage. Waiting for ${fmtSize(r.needMore)} more space — " +
                            "it can free space inside Super Share."
                        Thread.sleep(5000)
                        waited += 5000
                        if (waited > 15 * 60 * 1000L) { ui.status = "Stopped waiting for space. Tap Send to try again."; break }
                    } catch (e: IOException) {
                        if (cancel.get()) break
                        failures++
                        if (failures >= 4) throw e
                        ui.status = "Connection dropped, resuming… ($failures/4)"
                        Thread.sleep(2000)
                    }
                }
                if (cancel.get()) ui.status = "Stopped. Tap Send to continue where it stopped."
            } catch (e: Exception) {
                failure = e
            }
            val f = failure
            if (f != null) {
                lastHost = null     // the next tap re-joins the Wi-Fi link, then resumes from where it stopped
                ui.status = "Interrupted: ${f.message}. Tap Send to resume where it stopped."
            }
            ui.busy = false
            sending.set(false)
        }.start()
    }

    // ---------------- group share (sender hosts, several phones join) ----------------
    private fun startGroup() {
        stopAll(); ui.reset(); ui.screen = "group"; boost()
        ui.deselected = emptySet(); ui.devState.clear(); ui.devices = emptyList()
        val code = Keys.newCode()
        groupCode = code
        ui.code = Keys.pretty(code)
        ui.status = "Preparing the group…"
        Thread {
            try {
                val k = Keys.derive(code)
                runOnUiThread {
                    if (ui.screen != "group") return@runOnUiThread
                    try {
                        val reg = Registry()
                        reg.start(REG_PORT, null)
                        registry = reg
                        wd = WifiDirect(this, {}, { ui.status = it }).also { it.host(k) }
                    } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
                }
            } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
        }.start()
    }

    private fun sendGroup() {
        if (picked.isEmpty()) { ui.status = "Choose the files to send first"; return }
        val targets = ui.devices.filter { it.ip !in ui.deselected }
        if (targets.isEmpty()) { ui.status = "No phone has joined yet. Others: Receive, then Join a group."; return }
        if (groupRunning.get() > 0) return
        cancel.set(false)
        ui.busy = true
        ui.status = "Sending to ${targets.size} phone(s)…"
        val items = picked
        val code = groupCode
        val streams = if (targets.size > 2) 3 else 4
        groupRunning.set(targets.size)
        for (dev in targets) Thread { sendToDevice(dev, items, code, streams) }.start()
    }

    private fun sendToDevice(dev: DeviceInfo, items: List<Item>, code: String, streams: Int) {
        val sources = items.map { AndroidSource(applicationContext, it) }
        val meter = Meter()
        var last = 0f
        var failures = 0
        var waited = 0L
        ui.devState[dev.ip] = DevState(0f, 0f, "Starting…")
        try {
            while (!cancel.get()) {
                try {
                    val r = Sender.send(dev.ip, dev.port, code, sources, Progress { d, t ->
                        val s = meter.update(d, t)
                        if (s != null) { last = s.progress; ui.devState[dev.ip] = s }
                    }, cancel, streams)
                    failures = 0
                    if (r.complete) { ui.devState[dev.ip] = DevState(1f, 0f, "Done ✓"); break }
                    ui.devState[dev.ip] = DevState(last, 0f, "Waiting: needs ${fmtSize(r.needMore)} more space")
                    Thread.sleep(5000)
                    waited += 5000
                    if (waited > 15 * 60 * 1000L) { ui.devState[dev.ip] = DevState(last, 0f, "Stopped waiting for space"); break }
                } catch (e: IOException) {
                    if (cancel.get()) break
                    failures++
                    if (failures >= 4) throw e
                    ui.devState[dev.ip] = DevState(last, 0f, "Connection dropped, resuming… ($failures/4)")
                    Thread.sleep(2000)
                }
            }
            if (cancel.get()) ui.devState[dev.ip] = DevState(last, 0f, "Stopped")
        } catch (e: Exception) {
            ui.devState[dev.ip] = DevState(last, 0f, "Failed: ${e.message}")
        }
        if (groupRunning.decrementAndGet() <= 0) {
            val ok = ui.devState.values.count { it.status.startsWith("Done") }
            ui.status = "Finished: $ok of ${ui.devState.size} phone(s) received everything"
            ui.busy = false
        }
    }

    // ---------------- files ----------------
    private fun openFile(f: RFile) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(f.uri, f.mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: ActivityNotFoundException) {
            ui.message = "No app on this phone can open ${f.name}"
        }
    }

    private fun deleteFile(f: RFile) {
        try {
            contentResolver.delete(f.uri, null, null)
            refresh()
        } catch (e: SecurityException) {
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    val pi = MediaStore.createDeleteRequest(contentResolver, listOf(f.uri))
                    deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                } else if (e is RecoverableSecurityException) {
                    deleteLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
                } else ui.message = "Could not delete ${f.name}"
            } catch (e2: Exception) { ui.message = "Could not delete ${f.name}" }
        }
    }

    private fun openStorageSettings() {
        try { startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) }
        catch (e: Exception) { openSettings(Settings.ACTION_SETTINGS) }
    }

    private fun stopAll() {
        cancel.set(true)
        heartbeat?.interrupt(); heartbeat = null
        val r = receiver; receiver = null
        if (r != null) Thread { r.stop() }.start()       // stop() waits for saves, keep it off the UI thread
        val reg = registry; registry = null
        if (reg != null) Thread { reg.stop() }.start()
        wd?.stop(); wd = null
        lastHost = null
        ui.devices = emptyList(); ui.devState.clear()
        try { wifiLock?.release() } catch (e: Exception) { }
        wifiLock = null
        try { wakeLock?.release() } catch (e: Exception) { }
        wakeLock = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onDestroy() { stopAll(); super.onDestroy() }
}
