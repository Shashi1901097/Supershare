package com.supershare.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.supershare.app.core.Keys
import kotlinx.coroutines.delay

class Actions(
    val onReceive: () -> Unit,
    val onSend: () -> Unit,
    val onGroup: () -> Unit,
    val onJoinMode: () -> Unit,
    val onJoin: () -> Unit,
    val onPick: () -> Unit,
    val onPickMedia: () -> Unit,
    val onPickOther: () -> Unit,
    val onClear: () -> Unit,
    val onBrowse: () -> Unit,
    val onBrowseOpen: (String) -> Unit,
    val onBrowseUp: () -> Unit,
    val onBrowseToggle: (String) -> Unit,
    val onBrowseAll: () -> Unit,
    val onBrowseFolder: () -> Unit,
    val onBrowseDone: () -> Unit,
    val onAllFilesAccess: () -> Unit,
    val onStartSend: () -> Unit,
    val onSendGroup: () -> Unit,
    val onToggleDevice: (String) -> Unit,
    val onStop: () -> Unit,
    val onBack: () -> Unit,
    val onFiles: () -> Unit,
    val onManage: () -> Unit,
    val onOpen: (RFile) -> Unit,
    val onDelete: (RFile) -> Unit,
    val onDiscard: (Partial) -> Unit,
    val onStorageSettings: () -> Unit,
    val onWifi: () -> Unit,
    val onLocation: () -> Unit,
    val onDismissPrompt: () -> Unit,
    val onRefresh: () -> Unit
)

@Composable
fun AppScreen(ui: UiState, act: Actions) {
    BackHandler(enabled = ui.screen != "home") { act.onBack() }
    LaunchedEffect(Unit) {
        while (true) { act.onRefresh(); delay(2000) }
    }
    LaunchedEffect(ui.message) {
        if (ui.message.isNotEmpty()) { delay(4000); ui.message = "" }
    }
    var confirm by remember { mutableStateOf<RFile?>(null) }
    val pending = confirm
    if (pending != null) {
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Delete file?") },
            text = { Text("\"${pending.name}\" (${fmtSize(pending.size)}) will be deleted from this phone.") },
            confirmButton = { TextButton(onClick = { act.onDelete(pending); confirm = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }
    if (ui.prompt.isNotEmpty()) {
        val wifi = ui.prompt == "wifi"
        AlertDialog(
            onDismissRequest = { act.onDismissPrompt() },
            title = { Text(if (wifi) "Turn on Wi-Fi" else "Turn on Location") },
            text = {
                Text(if (wifi) "Please turn on Wi-Fi to send or receive files."
                else "Please turn on Location to send or receive files on this Android version.")
            },
            confirmButton = {
                TextButton(onClick = { if (wifi) act.onWifi() else act.onLocation() }) {
                    Text(if (wifi) "Turn on Wi-Fi" else "Turn on Location")
                }
            },
            dismissButton = { TextButton(onClick = { act.onDismissPrompt() }) { Text("Cancel") } }
        )
    }

    Screen(header = {
        when (ui.screen) {
            "home" -> Hero()
            "send", "group" -> Header("Send", act.onBack)
            "receive", "join" -> Header("Receive", act.onBack)
            "files" -> Header(if (ui.manage) "Free up space" else "My files", act.onBack)
            "browse" -> Header("Browse files", act.onBack)
            else -> Header("Super Share", act.onBack)
        }
    }) {
        when (ui.screen) {
            "home" -> HomeScreen(act)
            "receive" -> ReceiveScreen(ui, act) { confirm = it }
            "join" -> JoinScreen(ui, act) { confirm = it }
            "group" -> GroupScreen(ui, act)
            "browse" -> BrowseScreen(ui, act)
            "files" -> FilesScreen(ui, act) { confirm = it }
            else -> SendScreen(ui, act)
        }
    }
}

// ---------------- shared pieces ----------------

@Composable
private fun StatusText(ui: UiState) {
    if (ui.status.isEmpty()) return
    val done = ui.status.startsWith("Done")
    Text(ui.status, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
        color = if (done) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary,
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
}

@Composable
private fun MessageText(ui: UiState) {
    if (ui.message.isEmpty()) return
    Text(ui.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error,
        modifier = Modifier.padding(vertical = 4.dp))
}

/** The one place to choose files, plus a short summary of what is chosen. */
@Composable
private fun PickerRow(ui: UiState, act: Actions) {
    BrowseCard(ui.files.size) { act.onBrowse() }
    if (ui.files.isNotEmpty()) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${ui.files.size} file(s) · ${fmtSize(ui.files.sumOf { it.size })}",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f))
            TextButton(onClick = { act.onClear() }) { Text("Clear") }
        }
    }
}

@Composable
private fun CodeCard(label: String, code: String, hint: String) {
    SurfaceCard(horizontalAlignment = Alignment.CenterHorizontally) {
        SectionLabel(label)
        Spacer(Modifier.height(10.dp))
        CodeDigits(code)
        Spacer(Modifier.height(10.dp))
        Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

// ---------------- home ----------------

@Composable
private fun ColumnScope.HomeScreen(act: Actions) {
    Spacer(Modifier.height(28.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        ActionTile("Send", "up", Brush.linearGradient(listOf(BrandBlue, BrandViolet)), Modifier.weight(1f).height(170.dp), act.onSend)
        ActionTile("Receive", "down", Brush.linearGradient(listOf(BrandTeal, BrandBlue)), Modifier.weight(1f).height(170.dp), act.onReceive)
    }
    Spacer(Modifier.height(16.dp))
    OutlinedButton(onClick = act.onFiles, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)) {
        Text("My received files")
    }
    Spacer(Modifier.weight(1f))
    Text("© 2026 by Shashikumar H G", style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.outline, modifier = Modifier.align(Alignment.CenterHorizontally))
    Spacer(Modifier.height(12.dp))
}

// ---------------- receive ----------------

@Composable
private fun ColumnScope.ReceiveBody(ui: UiState, act: Actions, askDelete: (RFile) -> Unit) {
    if (ui.active) {
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Gauge(ui, 170.dp) }
        Spacer(Modifier.height(12.dp))
        Stats(ui)
        if (ui.current.isNotEmpty()) {
            Text("Receiving ${ui.current}", style = MaterialTheme.typography.bodyMedium, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
        }
    }
    if (ui.spaceAlert.isNotEmpty()) {
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer, contentColor = MaterialTheme.colorScheme.onErrorContainer)) {
            Column(Modifier.padding(16.dp)) {
                Text("Insufficient storage", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(4.dp))
                Text(ui.spaceAlert, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallButton("Free up space") { act.onManage() }
                    SmallButton("Phone storage") { act.onStorageSettings() }
                }
            }
        }
    }
    StatusText(ui)
    MessageText(ui)
    if (ui.recent.isNotEmpty()) {
        Spacer(Modifier.height(8.dp))
        SectionLabel("Received")
    }
    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
        items(ui.recent) { f -> ReceivedRow(f, act, askDelete, false) }
    }
}

@Composable
private fun ColumnScope.ReceiveScreen(ui: UiState, act: Actions, askDelete: (RFile) -> Unit) {
    Spacer(Modifier.height(16.dp))
    Segmented(listOf("My code", "Join a group"), 0) { act.onJoinMode() }
    Spacer(Modifier.height(16.dp))
    if (!ui.active) {
        CodeCard("Your code", ui.code, "Type this code on the sender's phone")
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            Spacer(Modifier.padding(horizontal = 6.dp))
            Text("Waiting for the sender", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    ReceiveBody(ui, act, askDelete)
}

@Composable
private fun ColumnScope.JoinScreen(ui: UiState, act: Actions, askDelete: (RFile) -> Unit) {
    Spacer(Modifier.height(16.dp))
    Segmented(listOf("My code", "Join a group"), 1) { act.onReceive() }
    Spacer(Modifier.height(16.dp))
    if (!ui.joined) {
        OutlinedTextField(
            value = ui.joinInput,
            onValueChange = { ui.joinInput = Keys.normalize(it) },
            label = { Text("Sender's 6-digit group code") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        PrimaryButton("Join group", enabled = ui.joinInput.length == Keys.CODE_LEN) { act.onJoin() }
        StatusText(ui)
        Text("The sender opens Send, taps Group and shows this code.", style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    } else {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon("check", MaterialTheme.colorScheme.tertiary, 20.dp)
            Spacer(Modifier.padding(horizontal = 4.dp))
            Text("Joined the group", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.titleSmall)
        }
        ReceiveBody(ui, act, askDelete)
    }
}

@Composable
private fun ReceivedRow(f: RFile, act: Actions, askDelete: (RFile) -> Unit, manage: Boolean) {
    Column {
        FileRow(f.name, fmtSize(f.size)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallButton("Open") { act.onOpen(f) }
                if (manage) SmallButton("Delete", danger = true) { askDelete(f) }
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    }
}

// ---------------- my files / free up space ----------------

@Composable
private fun ColumnScope.FilesScreen(ui: UiState, act: Actions, askDelete: (RFile) -> Unit) {
    Spacer(Modifier.height(16.dp))
    val used = ui.library.sumOf { it.size }
    SurfaceCard {
        Text("Super Share files: ${fmtSize(used)}", style = MaterialTheme.typography.titleSmall)
        Text("Free space on this phone: ${fmtSize(ui.free)}", style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (ui.manage) {
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = act.onStorageSettings, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(16.dp)) {
            Text("Open phone storage settings")
        }
    }
    MessageText(ui)
    Spacer(Modifier.height(8.dp))
    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
        if (ui.manage && ui.partials.isNotEmpty()) {
            item { SectionLabel("Unfinished transfers", Modifier.padding(vertical = 8.dp)) }
            items(ui.partials) { p ->
                Column {
                    FileRow(p.name, "${fmtSize(p.done)} of ${fmtSize(p.size)} received") {
                        SmallButton("Discard", danger = true) { act.onDiscard(p) }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
            }
        }
        item { SectionLabel("Received files", Modifier.padding(vertical = 8.dp)) }
        if (ui.library.isEmpty()) {
            item { Text("No received files yet.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        items(ui.library) { f -> ReceivedRow(f, act, askDelete, ui.manage) }
    }
}

// ---------------- browse every file ----------------

@Composable
private fun BrowseRow(e: BrowseEntry, checked: Boolean, onOpen: () -> Unit, onToggle: () -> Unit) {
    Column {
        ListItem(
            modifier = Modifier.clickable { if (e.dir) onOpen() else onToggle() },
            headlineContent = { Text(e.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            supportingContent = { Text(if (e.dir) "Folder" else fmtSize(e.size)) },
            leadingContent = { FileBadge(e.name, e.dir) },
            trailingContent = {
                if (e.dir) AppIcon("forward", MaterialTheme.colorScheme.onSurfaceVariant, 20.dp)
                else Checkbox(checked = checked, onCheckedChange = { onToggle() })
            },
            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
        )
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    }
}

@Composable
private fun ColumnScope.BrowseScreen(ui: UiState, act: Actions) {
    Spacer(Modifier.height(16.dp))
    if (!ui.allFiles) {
        SurfaceCard {
            Text("Super Share needs permission to see all files on this phone.", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp))
            SmallButton("Allow access to all files") { act.onAllFilesAccess() }
        }
        return
    }
    Text(ui.browsePath.removePrefix("/storage/emulated/0").ifEmpty { "Internal storage" }, style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SmallButton("Up") { act.onBrowseUp() }
        SmallButton("Select all here") { act.onBrowseAll() }
        SmallButton("Add whole folder") { act.onBrowseFolder() }
    }
    MessageText(ui)
    Spacer(Modifier.height(4.dp))
    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
        if (ui.browseEntries.isEmpty()) item { Text("This folder is empty.", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(8.dp)) }
        items(ui.browseEntries) { e ->
            BrowseRow(e, e.path in ui.browseSel, { act.onBrowseOpen(e.path) }, { act.onBrowseToggle(e.path) })
        }
    }
    Spacer(Modifier.height(8.dp))
    val n = ui.browseSel.size
    PrimaryButton(if (n > 0) "Add $n file(s)" else "Select files above", enabled = n > 0) { act.onBrowseDone() }
    Spacer(Modifier.height(8.dp))
}

// ---------------- send to one phone ----------------

@Composable
private fun ColumnScope.SendScreen(ui: UiState, act: Actions) {
    Spacer(Modifier.height(16.dp))
    Segmented(listOf("One phone", "Group"), 0) { act.onGroup() }
    Spacer(Modifier.height(16.dp))
    OutlinedTextField(
        value = ui.codeInput,
        onValueChange = { ui.codeInput = Keys.normalize(it) },
        label = { Text("Receiver's 6-digit code") },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth()
    )
    Spacer(Modifier.height(12.dp))
    PickerRow(ui, act)
    MessageText(ui)
    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
        items(ui.files) { f ->
            Column {
                FileRow(f.name, if (f.id in ui.blocked) "Waiting: receiver needs more storage" else fmtSize(f.size))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    }
    if (ui.active) {
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Gauge(ui, 150.dp) }
        Spacer(Modifier.height(8.dp))
        Stats(ui)
    }
    StatusText(ui)
    Spacer(Modifier.height(4.dp))
    if (ui.busy) {
        DangerButton("Stop") { act.onStop() }
    } else {
        PrimaryButton("Send", enabled = ui.files.isNotEmpty() && ui.codeInput.length == Keys.CODE_LEN) { act.onStartSend() }
    }
    Spacer(Modifier.height(8.dp))
}

// ---------------- group share (sender) ----------------

@Composable
private fun DeviceRow(d: DeviceInfo, checked: Boolean, st: DevState?, onToggle: () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        ListItem(
            headlineContent = { Text(d.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            supportingContent = {
                Text(if (st == null) d.ip else st.status + (if (st.mbps > 0f) "  ·  %.0f Mbps".format(st.mbps) else ""))
            },
            leadingContent = { Avatar(d.name) },
            trailingContent = { Checkbox(checked = checked, onCheckedChange = { onToggle() }) },
            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
        )
        if (st != null) {
            LinearProgressIndicator(progress = { st.progress }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(5.dp),
                trackColor = MaterialTheme.colorScheme.surfaceContainerHighest)
            Spacer(Modifier.height(8.dp))
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    }
}

@Composable
private fun ColumnScope.GroupScreen(ui: UiState, act: Actions) {
    Spacer(Modifier.height(16.dp))
    Segmented(listOf("One phone", "Group"), 1) { act.onSend() }
    Spacer(Modifier.height(16.dp))
    CodeCard("Group code", ui.code, "Others: Receive, Join a group, then type this code")
    Spacer(Modifier.height(12.dp))
    PickerRow(ui, act)
    MessageText(ui)
    Spacer(Modifier.height(12.dp))
    SectionLabel(if (ui.devices.isEmpty()) "Waiting for phones to join" else "Phones in the group")
    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
        items(ui.devices) { d ->
            DeviceRow(d, d.ip !in ui.deselected, ui.devState[d.ip]) { act.onToggleDevice(d.ip) }
        }
    }
    StatusText(ui)
    Spacer(Modifier.height(4.dp))
    if (ui.busy) {
        DangerButton("Stop") { act.onStop() }
    } else {
        val n = ui.devices.count { it.ip !in ui.deselected }
        PrimaryButton(if (n > 0) "Send to $n phone(s)" else "Send", enabled = ui.files.isNotEmpty() && n > 0) { act.onSendGroup() }
    }
    Spacer(Modifier.height(8.dp))
}
