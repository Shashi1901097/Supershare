#!/bin/sh
# Replays the virtual demo (needs a JDK 17+). Run from the project folder.
set -e
OUT=$(mktemp -d)
java -m jdk.compiler/com.sun.tools.javac.Main -d "$OUT" $(find app/src/main/java -name "*.java") \
  app/src/test/java/com/supershare/app/core/CoreTests.java app/src/test/java/com/supershare/app/core/Demo.java
java -Dstdout.encoding=UTF-8 -cp "$OUT" com.supershare.app.core.Demo "${1:-all}"
