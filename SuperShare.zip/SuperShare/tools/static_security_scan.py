#!/usr/bin/env python3
"""Static security checks for Super Share. Run from the project folder:  python3 tools/static_security_scan.py"""
import glob, os, re, sys
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
main_src = [f for f in glob.glob(root + '/app/src/main/**/*', recursive=True) if f.endswith(('.kt', '.java'))]
manifest = open(root + '/app/src/main/AndroidManifest.xml').read()
gradle = open(root + '/app/build.gradle.kts').read()
results = []
def check(name, ok, detail=''):
    results.append((ok, name, detail))

# ---- manifest ----
check('allowBackup is false', 'android:allowBackup="false"' in manifest)
check('cleartext traffic disabled', 'android:usesCleartextTraffic="false"' in manifest)
check('app is not debuggable in manifest', 'android:debuggable="true"' not in manifest)
exported = re.findall(r'<(activity|service|receiver|provider)[^>]*android:exported="true"', manifest)
check('only one exported component (launcher activity)', len(exported) == 1, str(exported))
check('no services/receivers/providers declared', not re.search(r'<(service|receiver|provider)\b', manifest))
perms = re.findall(r'<uses-permission android:name="([^"]+)"', manifest)
allowed = {'android.permission.INTERNET', 'android.permission.WAKE_LOCK', 'android.permission.ACCESS_WIFI_STATE',
           'android.permission.CHANGE_WIFI_STATE', 'android.permission.ACCESS_NETWORK_STATE',
           'android.permission.ACCESS_FINE_LOCATION', 'android.permission.NEARBY_WIFI_DEVICES',
           'android.permission.MANAGE_EXTERNAL_STORAGE', 'android.permission.READ_EXTERNAL_STORAGE'}
check('only the expected permissions are requested', set(perms) <= allowed, ', '.join(sorted(set(perms) - allowed)) or 'none extra')
dangerous = ['CAMERA', 'RECORD_AUDIO', 'READ_CONTACTS', 'READ_SMS', 'SEND_SMS',
             'WRITE_EXTERNAL_STORAGE', 'SYSTEM_ALERT_WINDOW', 'READ_PHONE_STATE',
             'ACCESS_BACKGROUND_LOCATION', 'REQUEST_INSTALL_PACKAGES', 'QUERY_ALL_PACKAGES']
check('no sensitive/restricted permissions', not any(d in manifest for d in dangerous))
check('location permission limited to Android 12 and older', 'ACCESS_FINE_LOCATION" android:maxSdkVersion="32"' in manifest)
check('NEARBY_WIFI_DEVICES declared neverForLocation', 'neverForLocation' in manifest)
check('all-files access is requested only so the user can browse and pick files (legacy read permission limited to Android 10)', 'MANAGE_EXTERNAL_STORAGE' in manifest and 'READ_EXTERNAL_STORAGE" android:maxSdkVersion="29"' in manifest)
listing = [os.path.relpath(f, root) for f in main_src if 'listFiles' in open(f).read()]
check('folders are listed only by the file browser and the app-private resume folder', set(listing) <= {'app/src/main/java/com/supershare/app/MainActivity.kt', 'app/src/main/java/com/supershare/app/Library.kt'}, ', '.join(listing))

# ---- gradle ----
check('targets Android 16 (API 36) as Google Play requires', 'targetSdk = 36' in gradle)
check('release build is minified and shrunk', 'isMinifyEnabled = true' in gradle and 'isShrinkResources = true' in gradle)
check('no hard-coded signing config in build file', 'storePassword' not in gradle and 'keyPassword' not in gradle)

# ---- source patterns (app code only, tests excluded) ----
patterns = {
    'no shell/process execution': r'Runtime\.getRuntime\(\)\.exec|ProcessBuilder',
    'no WebView / JavaScript bridge': r'WebView|addJavascriptInterface',
    'no custom TLS trust/hostname overrides': r'TrustManager|HostnameVerifier|SSLSocketFactory',
    'no logging of data (Log.*, printStackTrace)': r'\bLog\.[a-z]\(|printStackTrace',
    'no world-readable files': r'MODE_WORLD_|setReadable\(true, *false\)',
    'no dynamic code loading / reflection': r'DexClassLoader|PathClassLoader|Class\.forName|setAccessible',
    'no plain URLs / hosts in code': r'https?://',
    'no non-secure random': r'new Random\(|Math\.random|kotlin\.random',
    'no non-constant-time MAC comparison': r'Arrays\.equals\(',
    'no weak hashes (MD5/SHA-1) or DES': r'"MD5"|"SHA-1"|"SHA1"|"DES"|"RC4"',
    'no hard-coded secrets': r'(?i)(password|secret|api[_-]?key|token)\s*=\s*"[^"]{4,}"|BEGIN (RSA |EC )?PRIVATE KEY',
}
for name, pat in patterns.items():
    hits = []
    for f in main_src:
        for n, line in enumerate(open(f).read().splitlines(), 1):
            s = line.strip()
            if s.startswith(('//', '*', '/*')): continue
            if re.search(pat, line): hits.append(f'{os.path.relpath(f, root)}:{n}')
    check(name, not hits, ', '.join(hits[:5]))

core = root + '/app/src/main/java/com/supershare/app/core/'
check('constant-time proof comparison is used', 'MessageDigest.isEqual' in open(core + 'Crypto.java').read())
check('pairing code comes from SecureRandom', 'new SecureRandom()' in open(core + 'Keys.java').read())
check('SRP-6a password-authenticated key exchange with a 2048-bit group', 'RFC 3526' in open(core + 'Srp.java').read() and 'validPublic' in open(core + 'Srp.java').read())
check('all file data is encrypted with AES-256-GCM', 'AES/GCM/NoPadding' in open(core + 'Crypto.java').read())
check('no unauthenticated cipher modes (ECB/CBC/CTR)', not any(re.search(r'AES/(ECB|CBC|CTR)', open(f).read()) for f in main_src))
check('session keys are bound to the connection (fresh nonce per connection)', 'rnd.nextBytes(nonce)' in open(core + 'Receiver.java').read())
check('receiver locks out after repeated wrong codes', 'MAX_AUTH_FAILURES' in open(core + 'Receiver.java').read())
check('group guest list limits the number of devices', 'MAX_DEVICES' in open(core + 'Registry.java').read())
keys = [f for f in glob.glob(root + '/**/*', recursive=True) if f.endswith(('.jks', '.keystore', '.p12', '.pem', '.key'))]
check('no key files in the project', not keys, ', '.join(keys))

bad = 0
for ok, name, detail in results:
    print(('PASS  ' if ok else 'FAIL  ') + name + (f'   [{detail}]' if detail and not ok else ''))
    bad += 0 if ok else 1
print(f'\n{len(results) - bad}/{len(results)} static checks passed')
sys.exit(1 if bad else 0)
