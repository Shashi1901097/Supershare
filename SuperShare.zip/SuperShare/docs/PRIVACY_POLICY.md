# Privacy Policy – Super Share
Last updated: 2026

Super Share (by Shashikumar H G) sends files directly between two phones over a private Wi-Fi Direct connection.

- **We collect no personal data.** The app has no accounts, no analytics, no advertising and no servers.
- **Files** you send or receive travel only between the two phones and are stored only on the receiving phone
  (Downloads/SuperShare). They are never uploaded anywhere.
- **Permissions**: "Nearby devices" (Android 13+) or "Location" (Android 12 and older) are required by Android to use
  Wi-Fi Direct. The app does not read or store your location.
- **All-files access**: so you can send any file, Super Share can ask Android for "access to all files". It is used only to show the folder browser and to read the files you tick. Nothing is read, copied or uploaded otherwise.
- **Deleting data**: delete received files inside the app or in your Files app; uninstalling the app removes its data.

Contact: <add your e-mail address here>
