# Super Share – security design and test report

Everything below was run against the real sender/receiver code. Attacks were *simulated* on one computer (loopback
network). That is a strong check of the transfer engine, but it is not a replacement for testing on real phones or for
a professional penetration test.

## How transfers are protected
- **6-digit random code** (new for every session). Short codes are normally weak, so the code is never used as a key:
  it is the password of an **SRP-6a key exchange** (2048-bit group). Both phones end up with the same strong session
  key only if they used the same code, and a recording of the conversation gives an eavesdropper nothing to test
  guesses against offline. Every guess needs a live attempt, and the receiver **locks out after 5 wrong attempts**.
- **Everything is encrypted and authenticated with AES-256-GCM**: file names, sizes and file data. Each connection has
  its own keys; numbered blocks mean data cannot be altered, repeated, dropped or reordered. A damaged block stops
  the transfer and is never written.
- The private **Wi-Fi Direct group** is locked with a name/password derived from the code. Because 6 digits are easy to
  crack, treat it only as a door lock; the real protection is the key exchange and encryption above.
- **Group share**: the sender hosts the group and sees every phone that joined (name + address) and can untick any
  unknown one. Files go only to phones that complete the code-protected login.
- **Untrusted input is validated**: file count, total size claimed, ids, block numbers; file names are reduced to a plain
  name (no folders, no `..`, no control characters); at most 32 connections; unauthenticated connections are dropped
  after 5 s; the sender also refuses oversized replies.
- **Storage safety**: files that do not fit into free space (minus a 100 MB reserve) are refused and reported.
- **Privacy**: no accounts, analytics, ads or servers. Backups disabled. Files are saved only in Downloads/SuperShare.

## Results: 27 automated tests (all pass; suite also run 5 more times in a row without a failure) + 34 static checks
| Test | What it proves |
|---|---|
| srp / frameCipher | same code => same key, wrong code => different key; degenerate values rejected; repeated, altered or reordered blocks fail |
| keys / codeDistribution | codes are 6 random digits, uniformly distributed |
| transfer / allFileTypes | 20 file types (zip, tar.gz, gz, exe, iso, apk, 7z, rar, sqlite, no extension, hidden ...) and sizes 0 B to 45 MB arrive byte-identical (SHA-256) |
| resume | receiver killed mid-transfer; second run continues from saved progress |
| insufficientStorage / manyFiles | exact shortfall reported; 200 files into space for 80 stores exactly 80; completes after space is freed |
| alreadyHave | files already received are not sent again |
| concurrentSenders / groupSend | 4 senders to one receiver, and 1 sender to 3 phones at once: every file intact |
| registry | guest list: hostile names cleaned, bad messages ignored, limited to 8 devices, stale devices disappear |
| wrongCodeAndLockout / replay | wrong code stores nothing; lock-out after 5 attempts; recorded logins and data proofs cannot be replayed |
| eavesdropperSeesNothing | a recorder of the whole conversation sees neither file content, file name nor the code |
| tamperedTraffic | one flipped bit is detected; a damaged file is never published; clean retry is bit-identical |
| authenticatedHostileMessages / memoryExhaustionGuards / fuzzReceiver | hostile or random messages (even from a logged-in peer) are dropped; 370 fuzz rounds leave the receiver working |
| idleAndConnectionFlood | idle peers dropped after 5 s; connection flood is capped; receiver recovers |
| maliciousReceiver | a fake receiver (bad key values, wrong proof, gigantic reply) is refused |
| nameFuzz / pathTraversalName | 40,000 hostile file names always become safe plain names |
| cancel | Stop ends the transfer promptly and publishes no half file |

## All-files access
`MANAGE_EXTERNAL_STORAGE` lets the in-app browser list every folder so any file type can be chosen. The app only
reads the files the user ticks (or a folder the user adds). The static scan checks that folder listing exists only
in the browser and in the app's private resume folder. 23 odd real-world file names (hidden files, many dots,
symbols, 150-character names, no extension) are tested to arrive byte-identical with the exact name.

## Virtual run (`Demo.java`)
`java ... com.supershare.app.core.Demo` replays five scenarios with simulated phones (one-to-one, low storage, resume
after Wi-Fi loss, group share to 3 phones, attacks) and prints what each phone would show.

## Speed
Encrypted engine throughput measured on a single CPU core (loopback, includes encryption): about 600 MB/s (~5 Gbps).
Encryption is therefore not the bottleneck; real speed depends on both phones' Wi-Fi hardware and storage.
Settings used: 512 KB encrypted blocks, up to 12 parallel streams for one receiver (3-4 per phone in a group).

## What has NOT been tested – please do before publishing
- The Android layer (Wi-Fi Direct joining and hosting, MediaStore saving, the screens, the Wi-Fi/Bluetooth shortcuts,
  group joining) was written and reviewed but could not be run on phones here. **Test on at least three real phones.**
- No third-party penetration test or code audit. SRP and AES-GCM come from standard, well-studied designs, but this
  combination was written for this app; an independent review is advisable before wide release.
- A Wi-Fi Direct group supports only as many phones as the chip allows (often 3 to 7).
- Files that live only in the cloud (for example Google Drive files not downloaded) cannot be sent; download them first.
- Android does not allow apps to switch Wi-Fi or Bluetooth on silently; the app opens the system panel instead.
