package com.supershare.app.core;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Small crypto helpers: HMAC, key derivation, and AES-256-GCM framing. */
public final class Crypto {
    private Crypto() {}

    public static byte[] hmac(byte[] key, String label, byte[]... parts) {
        try {
            Mac m = Mac.getInstance("HmacSHA256");
            m.init(new SecretKeySpec(key, "HmacSHA256"));
            m.update(label.getBytes(StandardCharsets.UTF_8));
            for (byte[] p : parts) { m.update((byte) (p.length >> 8)); m.update((byte) p.length); m.update(p); }
            return m.doFinal();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }

    /** One 32-byte key for a given purpose, bound to the connection. */
    public static byte[] derive(byte[] key, String purpose, byte[] connectionNonce) {
        return hmac(key, "derive:" + purpose, connectionNonce);
    }

    public static boolean equal(byte[] a, byte[] b) { return MessageDigest.isEqual(a, b); }

    /**
     * Seals / opens numbered frames. Each connection direction has its own key and a frame counter that is
     * used as the nonce and as authenticated data, so frames cannot be altered, dropped, repeated or reordered.
     */
    public static final class FrameCipher {
        private final SecretKeySpec key;
        private final boolean encrypt;
        private final Cipher cipher;
        private long counter = 0;

        public FrameCipher(byte[] key32, boolean encrypt) throws GeneralSecurityException {
            this.key = new SecretKeySpec(key32, "AES");
            this.encrypt = encrypt;
            this.cipher = Cipher.getInstance("AES/GCM/NoPadding");
        }

        private byte[] counterBytes() {
            byte[] c = new byte[8];
            long v = counter;
            for (int i = 7; i >= 0; i--) { c[i] = (byte) v; v >>>= 8; }
            return c;
        }

        private void init() throws GeneralSecurityException {
            byte[] c = counterBytes();
            byte[] iv = new byte[12];
            System.arraycopy(c, 0, iv, 4, 8);
            cipher.init(encrypt ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
            cipher.updateAAD(c);
        }

        /** dst must have room for len + 16 bytes. Returns the sealed length. */
        public int seal(byte[] src, int off, int len, byte[] dst) throws GeneralSecurityException {
            init();
            int n = cipher.doFinal(src, off, len, dst, 0);
            counter++;
            return n;
        }

        /** dst must have room for ctLen bytes. Returns the plain length; throws if anything was changed. */
        public int open(byte[] ct, int ctLen, byte[] dst) throws GeneralSecurityException {
            init();
            int n = cipher.doFinal(ct, 0, ctLen, dst, 0);
            counter++;
            return n;
        }
    }
}
