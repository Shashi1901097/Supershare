package com.supershare.app.core;

import java.io.IOException;
import java.util.BitSet;

public interface TargetFactory {
    /** Free bytes on the receiver's storage right now. */
    long freeBytes();

    /** True if this exact file was already received and still exists. */
    boolean alreadyHave(String id, long size);

    /** Saved progress for a partly received file, or null. Must not create anything. */
    BitSet peekBits(String id, long size);

    /** Opens the partial file for this id (creating it if needed). */
    Target open(String id, String name, long size) throws IOException;
}
