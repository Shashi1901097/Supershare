package com.supershare.app.core;

/** Makes a file name from an untrusted peer safe to use as a plain file name. */
public final class Names {
    private Names() {}

    public static String sanitize(String raw) {
        if (raw == null) return "file";
        String s = raw.replace('\\', '/');
        int slash = s.lastIndexOf('/');
        if (slash >= 0) s = s.substring(slash + 1);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c < 0x20 || c == 0x7f) continue;                       // control characters
            if (":*?\"<>|".indexOf(c) >= 0) b.append('_'); else b.append(c);
        }
        s = b.toString().trim();
        while (s.endsWith(".") || s.endsWith(" ")) s = s.substring(0, s.length() - 1);
        if (s.isEmpty() || s.equals(".") || s.equals("..")) return "file";
        if (s.length() > Protocol.MAX_NAME) {
            int dot = s.lastIndexOf('.');
            String ext = (dot > 0 && s.length() - dot <= 12) ? s.substring(dot) : "";
            s = s.substring(0, Protocol.MAX_NAME - ext.length()) + ext;
        }
        return s;
    }
}
