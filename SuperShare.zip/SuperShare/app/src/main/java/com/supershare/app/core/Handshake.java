package com.supershare.app.core;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.math.BigInteger;
import java.net.Socket;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;

/** The login steps. Sender = client, receiver = server. */
final class Handshake {
    private Handshake() {}

    static final int PROOF = 32;

    // ---------------- client (sender) ----------------

    /** Full login with the pairing code. The socket must already be connected. */
    static Link clientQuery(Socket s, String code, SecureRandom rnd) throws IOException {
        DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream(), 8192));
        DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
        byte[] nonce = new byte[16];
        try { in.readFully(nonce); }
        catch (EOFException e) { throw new IOException("Receiver is not available"); }
        out.writeByte(Protocol.T_QUERY);
        Srp.Client c = new Srp.Client(code, rnd);
        byte[] a = c.publicA();
        out.writeInt(a.length);
        out.write(a);
        out.flush();

        byte[] salt = new byte[16], b = new byte[Srp.LEN], sid = new byte[8];
        try {
            in.readFully(salt);
            if (in.readInt() != Srp.LEN) throw new IOException("Unexpected reply from receiver");
            in.readFully(b);
            in.readFully(sid);
        } catch (EOFException e) {
            throw new IOException("Receiver is not accepting connections (too many wrong codes?)");
        }
        byte[] key;
        try { key = c.sessionKey(salt, b); }
        catch (GeneralSecurityException e) { throw new IOException("Receiver sent an invalid value"); }
        byte[] m1 = Crypto.hmac(key, "M1", nonce, a, b, salt, sid);
        out.write(m1);
        out.flush();
        byte[] m2 = new byte[PROOF];
        try { in.readFully(m2); }
        catch (EOFException e) { throw new IOException("Wrong code"); }
        if (!Crypto.equal(m2, Crypto.hmac(key, "M2", nonce, m1))) throw new IOException("Receiver could not prove the code");
        return new Link(s, in, out, sid, key, nonce, false);
    }

    /** Login for an extra data connection of an already established session. */
    static Link clientData(Socket s, byte[] sid, byte[] key) throws IOException {
        DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream(), 8192));
        DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
        byte[] nonce = new byte[16];
        try { in.readFully(nonce); }
        catch (EOFException e) { throw new IOException("Receiver is busy or refused the connection"); }
        out.writeByte(Protocol.T_DATA);
        out.write(sid);
        out.write(Crypto.hmac(key, "DATA", nonce, sid));
        out.flush();
        return new Link(s, in, out, sid, key, nonce, false);
    }

    // ---------------- server (receiver) ----------------

    /** Runs the receiver side of the login. Returns null when the sender did not know the code. */
    static Link serverQuery(Socket s, DataInputStream in, DataOutputStream out, byte[] nonce, byte[] salt,
                            BigInteger verifier, SecureRandom rnd) throws IOException {
        if (in.readInt() != Srp.LEN) throw new IOException("bad A");
        byte[] a = new byte[Srp.LEN];
        in.readFully(a);
        Srp.Server srv = new Srp.Server(verifier, rnd);
        byte[] key;
        try { key = srv.sessionKey(a); }
        catch (GeneralSecurityException e) { throw new IOException("bad A"); }
        byte[] sid = new byte[8];
        rnd.nextBytes(sid);
        byte[] b = srv.publicB();
        out.write(salt);
        out.writeInt(b.length);
        out.write(b);
        out.write(sid);
        out.flush();
        byte[] m1 = new byte[PROOF];
        in.readFully(m1);
        if (!Crypto.equal(m1, Crypto.hmac(key, "M1", nonce, a, b, salt, sid))) return null;
        out.write(Crypto.hmac(key, "M2", nonce, m1));
        out.flush();
        return new Link(s, in, out, sid, key, nonce, true);
    }

    static Link serverData(Socket s, DataInputStream in, DataOutputStream out, byte[] nonce,
                           byte[] sid, byte[] key) throws IOException {
        return new Link(s, in, out, sid, key, nonce, true);
    }
}
