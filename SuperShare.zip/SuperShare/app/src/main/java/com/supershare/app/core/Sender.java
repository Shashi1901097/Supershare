package com.supershare.app.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Sends files. It logs in with the code, asks the receiver what it already has and whether the rest fits into
 * its free space, then sends only the missing 4 MB chunks over several parallel encrypted streams.
 */
public final class Sender {
    public static final long STALL_NANOS = 30_000_000_000L;

    public static final class Result {
        /** True when nothing is left to send (everything stored, or already there). */
        public final boolean complete;
        /** Ids of files the receiver has no room for. */
        public final List<String> blockedIds;
        public final int haveCount;
        public final long needMore;
        public final long receiverFree;

        Result(boolean complete, List<String> blockedIds, int haveCount, long needMore, long receiverFree) {
            this.complete = complete; this.blockedIds = blockedIds; this.haveCount = haveCount;
            this.needMore = needMore; this.receiverFree = receiverFree;
        }
    }

    private static final class Reply {
        long free;
        byte[] status;
        long[] need;
        BitSet[] bits;
    }

    private static final class Task {
        final Source src; final int start; final int count; final long bytes;
        Task(Source src, int start, int count) {
            this.src = src; this.start = start; this.count = count;
            this.bytes = Math.min((long) count * Protocol.CHUNK, src.size() - (long) start * Protocol.CHUNK);
        }
    }

    private Sender() {}

    public static Result send(String host, int port, String code, List<? extends Source> files,
                              Progress progress, AtomicBoolean cancel) throws IOException {
        return send(host, port, code, files, progress, cancel, Protocol.BIG_STREAMS);
    }

    /** maxStreams: parallel connections per big file (use fewer when sending to several phones at once). */
    public static Result send(String host, int port, String code, List<? extends Source> files,
                              Progress progress, AtomicBoolean cancel, int maxStreams) throws IOException {
        if (maxStreams < 1) maxStreams = 1;
        if (!Keys.isValid(code)) throw new IOException("The code must be 6 digits");
        long total = 0;
        for (Source s : files) {
            if (s.size() < 0) throw new IOException("Bad file size: " + s.name());
            total += s.size();
        }
        SecureRandom rnd = new SecureRandom();
        Reply q;
        byte[] sid, key;
        try (Link link = login(host, port, code, rnd)) {
            sid = link.sessionId;
            key = link.sessionKey;
            q = query(link, files);
        }

        long already = 0;
        for (int i = 0; i < files.size(); i++) already += Protocol.doneBytes(q.bits[i], files.get(i).size());
        AtomicLong sent = new AtomicLong(already);
        progress.onProgress(already, total);

        List<Task> tasks = new ArrayList<>();
        List<String> blocked = new ArrayList<>();
        int have = 0;
        long needMore = 0;
        for (int i = 0; i < files.size(); i++) {
            Source f = files.get(i);
            if (q.status[i] == Protocol.S_NO_SPACE) {
                blocked.add(f.id());
                needMore = Math.max(needMore, q.need[i]);
                continue;
            }
            if (q.status[i] == Protocol.S_HAVE) { have++; continue; }
            int chunks = Protocol.chunksOf(f.size());
            BitSet bits = q.bits[i];
            int c = bits.nextClearBit(0);
            while (c < chunks) {
                int next = bits.nextSetBit(c);
                int e = (next < 0 || next > chunks) ? chunks : next;
                int runChunks = e - c;
                long runBytes = Math.min((long) runChunks * Protocol.CHUNK, f.size() - (long) c * Protocol.CHUNK);
                int pieces = runBytes > Protocol.SPLIT_ABOVE ? Math.min(maxStreams, runChunks) : 1;
                int per = (runChunks + pieces - 1) / pieces;
                int x = c;
                while (x < e) { int k = Math.min(per, e - x); tasks.add(new Task(f, x, k)); x += k; }
                c = bits.nextClearBit(e);
            }
        }
        if (!tasks.isEmpty()) runTasks(host, port, sid, key, tasks, total, sent, progress, cancel);
        return new Result(blocked.isEmpty(), blocked, have, needMore, q.free);
    }

    private static Link login(String host, int port, String code, SecureRandom rnd) throws IOException {
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(host, port), 8000);
            s.setSoTimeout(15000);
            return Handshake.clientQuery(s, code, rnd);
        } catch (IOException | RuntimeException e) {
            try { s.close(); } catch (IOException ignored) {}
            throw e;
        }
    }

    private static Reply query(Link link, List<? extends Source> files) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        DataOutputStream o = new DataOutputStream(bo);
        o.writeInt(files.size());
        for (Source f : files) { o.writeUTF(f.id()); o.writeUTF(f.name()); o.writeLong(f.size()); }
        if (bo.size() > Protocol.MAX_QUERY_PLAIN) throw new IOException("Too many files in one batch");
        link.send(bo.toByteArray(), 0, bo.size());

        byte[] plain;
        try { plain = link.recv(Protocol.MAX_QUERY_PLAIN); }
        catch (java.io.EOFException e) { throw new IOException("Receiver refused the request"); }
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(plain));
        Reply r = new Reply();
        r.free = in.readLong();
        int n = in.readInt();
        if (n != files.size()) throw new IOException("Unexpected reply from receiver");
        r.status = new byte[n]; r.need = new long[n]; r.bits = new BitSet[n];
        for (int i = 0; i < n; i++) {
            r.status[i] = in.readByte();
            r.need[i] = in.readLong();
            int len = in.readInt();
            if (len < 0 || len > (Protocol.MAX_FILE_SIZE / Protocol.CHUNK / 8) + 16 || len > in.available())
                throw new IOException("Bad reply");
            byte[] b = new byte[len];
            in.readFully(b);
            r.bits[i] = BitSet.valueOf(b);
        }
        return r;
    }

    private static void runTasks(String host, int port, byte[] sid, byte[] key, List<Task> tasks, long total,
                                 AtomicLong sent, Progress progress, AtomicBoolean cancel) throws IOException {
        Collections.sort(tasks, (a, b) -> Long.compare(b.bytes, a.bytes));
        final ExecutorService pool = Executors.newFixedThreadPool(Math.min(Protocol.MAX_THREADS, tasks.size()));
        final Set<Closeable> live = ConcurrentHashMap.newKeySet();
        final AtomicLong lastMove = new AtomicLong(System.nanoTime());
        final AtomicBoolean abort = new AtomicBoolean(false);
        final ScheduledExecutorService dog = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "sender-watchdog");
            t.setDaemon(true);
            return t;
        });
        dog.scheduleWithFixedDelay(() -> {
            if (cancel.get() || System.nanoTime() - lastMove.get() > STALL_NANOS) { abort.set(true); closeAll(live); }
        }, 1, 1, TimeUnit.SECONDS);
        try {
            List<Future<Void>> fs = new ArrayList<>();
            for (final Task t : tasks) {
                fs.add(pool.submit((Callable<Void>) () -> {
                    sendTask(host, port, sid, key, t, total, sent, progress, lastMove, live, abort, cancel);
                    return null;
                }));
            }
            for (Future<Void> f : fs) {
                try { f.get(); }
                catch (ExecutionException e) {
                    abort.set(true); closeAll(live);
                    if (cancel.get()) throw new IOException("Cancelled");
                    Throwable c = e.getCause();
                    if (c instanceof IOException) throw (IOException) c;
                    throw new IOException(String.valueOf(c));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    abort.set(true); closeAll(live);
                    throw new IOException("Interrupted");
                }
            }
        } finally {
            dog.shutdownNow();
            pool.shutdownNow();
        }
    }

    private static void closeAll(Set<Closeable> live) {
        for (Closeable c : live) { try { c.close(); } catch (IOException ignored) {} }
    }

    private static void sendTask(String host, int port, byte[] sid, byte[] key, Task t, long total, AtomicLong sent,
                                 Progress progress, AtomicLong lastMove, Set<Closeable> live,
                                 AtomicBoolean abort, AtomicBoolean cancel) throws IOException {
        try (Opened o = t.src.open(); Socket s = new Socket()) {
            live.add(s);
            try {
                s.setTcpNoDelay(true);
                try { s.setSendBufferSize(8 << 20); } catch (java.net.SocketException ignored) {}
                s.connect(new InetSocketAddress(host, port), 8000);
                s.setSoTimeout(15000);
                Link link = Handshake.clientData(s, sid, key);

                ByteArrayOutputStream hb = new ByteArrayOutputStream();
                DataOutputStream h = new DataOutputStream(hb);
                h.writeUTF(t.src.id());
                h.writeInt(t.start);
                h.writeInt(t.count);
                link.send(hb.toByteArray(), 0, hb.size());

                FileChannel fc = o.channel();
                long pos = (long) t.start * Protocol.CHUNK;
                long end = pos + t.bytes;
                ByteBuffer bb = ByteBuffer.allocate(Protocol.DATA_FRAME);
                byte[] arr = bb.array();
                while (pos < end) {
                    if (cancel.get() || abort.get()) throw new IOException("Cancelled");
                    int want = (int) Math.min(Protocol.DATA_FRAME, end - pos);
                    bb.clear();
                    bb.limit(want);
                    int got = 0;
                    while (bb.hasRemaining()) {
                        int r = fc.read(bb, pos + got);
                        if (r < 0) throw new IOException("File ended early: " + t.src.name());
                        got += r;
                    }
                    link.send(arr, 0, want);
                    pos += want;
                    lastMove.set(System.nanoTime());
                    progress.onProgress(sent.addAndGet(want), total);
                }
                s.setSoTimeout(60000);
                byte[] ack = new byte[1 + 16];
                int n;
                try { n = link.recv(ack, 1); }
                catch (java.net.SocketTimeoutException e) { throw new IOException("Receiver did not confirm"); }
                if (n != 1 || ack[0] != 1) throw new IOException("Receiver did not confirm the data");
            } finally {
                live.remove(s);
            }
        }
    }
}
