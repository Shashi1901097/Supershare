package com.supershare.app.core;

import java.io.IOException;

public interface Source {
    String id();
    String name();
    long size();
    Opened open() throws IOException;
}
