package com.supershare.app

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.supershare.app.core.Protocol
import java.io.File

class RFile(val uri: Uri, val name: String, val size: Long, val mime: String, val added: Long)
class Partial(val id: String, val name: String, val size: Long, val done: Long, val uri: Uri)

object Library {
    fun list(ctx: Context): List<RFile> {
        val out = ArrayList<RFile>()
        val proj = arrayOf(
            MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME,
            MediaStore.Downloads.SIZE, MediaStore.Downloads.MIME_TYPE, MediaStore.Downloads.DATE_ADDED
        )
        try {
            ctx.contentResolver.query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI, proj,
                "${MediaStore.Downloads.RELATIVE_PATH} LIKE ?", arrayOf("$FOLDER%"),
                "${MediaStore.Downloads.DATE_ADDED} DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    out.add(RFile(
                        ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id),
                        c.getString(1) ?: "file", c.getLong(2), c.getString(3) ?: "*/*", c.getLong(4)))
                }
            }
        } catch (e: Exception) { }
        return out
    }

    fun partials(ctx: Context): List<Partial> {
        val dir = File(ctx.filesDir, "resume")
        val out = ArrayList<Partial>()
        dir.listFiles { f -> f.name.endsWith(".txt") }?.forEach { f ->
            try {
                val l = f.readLines()
                val size = l[2].toLong()
                val done = Protocol.doneBytes(parseBits(l.getOrElse(3) { "" }), size)
                out.add(Partial(f.name.removeSuffix(".txt"), l[1], size, done, Uri.parse(l[0])))
            } catch (e: Exception) { }
        }
        return out
    }

    fun discard(ctx: Context, p: Partial) {
        try { ctx.contentResolver.delete(p.uri, null, null) } catch (e: Exception) { }
        File(File(ctx.filesDir, "resume"), "${p.id}.txt").delete()
    }
}
