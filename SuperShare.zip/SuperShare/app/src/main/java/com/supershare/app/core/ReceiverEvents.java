package com.supershare.app.core;

public interface ReceiverEvents {
    /** A sender announced a batch. blocked = files that do not fit into the free space. */
    default void onBatch(long done, long total, int blocked, long maxNeedMore, String firstBlockedName) {}
    default void onProgress(long done, long total) {}
    default void onFileStart(String name) {}
    default void onFileDone(String name) {}
    default void onAuthFailed(int totalFailures) {}
}
