package com.supershare.app.core;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * The pairing code is 6 random digits. It is only used (1) to name/lock the private Wi-Fi Direct group, which
 * merely controls who can join, and (2) as the password of the SRP key exchange, which protects the files.
 * Because of SRP a captured conversation cannot be used to guess the code offline.
 */
public final class Keys {
    public static final int CODE_LEN = 6;
    public static final int ITERATIONS = 10_000;
    private static final byte[] SALT = "SuperShare/v2/wifi".getBytes(StandardCharsets.UTF_8);

    public final String wifiName;
    public final String wifiPass;

    private Keys(String wifiName, String wifiPass) {
        this.wifiName = wifiName;
        this.wifiPass = wifiPass;
    }

    public static String newCode() {
        return String.format("%06d", new SecureRandom().nextInt(1_000_000));
    }

    /** Keeps only digits, at most six. */
    public static String normalize(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length() && b.length() < CODE_LEN; i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') b.append(c);
        }
        return b.toString();
    }

    public static boolean isValid(String code) {
        if (code == null || code.length() != CODE_LEN) return false;
        for (int i = 0; i < code.length(); i++) {
            char c = code.charAt(i);
            if (c < '0' || c > '9') return false;
        }
        return true;
    }

    /** 123456 -> "123 456" */
    public static String pretty(String code) {
        return code.length() == CODE_LEN ? code.substring(0, 3) + " " + code.substring(3) : code;
    }

    public static Keys derive(String code) throws GeneralSecurityException {
        return derive(code, ITERATIONS);
    }

    public static Keys derive(String code, int iterations) throws GeneralSecurityException {
        if (!isValid(code)) throw new IllegalArgumentException("Invalid code");
        PBEKeySpec spec = new PBEKeySpec(code.toCharArray(), SALT, iterations, 20 * 8);
        byte[] k;
        try {
            k = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } finally {
            spec.clearPassword();
        }
        return new Keys("DIRECT-SS-" + hex(k, 0, 4), hex(k, 4, 16));
    }

    private static String hex(byte[] b, int off, int len) {
        StringBuilder sb = new StringBuilder();
        for (int i = off; i < off + len; i++) sb.append(String.format("%02x", b[i]));
        return sb.toString();
    }
}
