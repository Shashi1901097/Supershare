package com.supershare.app.core;

public interface Progress {
    void onProgress(long done, long total);
}
