package com.supershare.app

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Handler
import androidx.core.content.ContextCompat
import com.supershare.app.core.Keys

/**
 * The receiver creates a private Wi-Fi Direct group (5 GHz when the phone supports it) whose name and
 * password come from the random pairing code. The sender joins that group directly.
 */
@SuppressLint("MissingPermission")
class WifiDirect(
    private val ctx: Context,
    private val onConnected: (WifiP2pInfo) -> Unit,
    private val onStatus: (String) -> Unit
) {
    private val mgr = ctx.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
    private val ch = mgr.initialize(ctx, ctx.mainLooper, null)
    private val main = Handler(ctx.mainLooper)
    private var registered = false

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION) {
                mgr.requestConnectionInfo(ch) { if (it.groupFormed) onConnected(it) }
            }
        }
    }

    private fun register() {
        if (registered) return
        ContextCompat.registerReceiver(ctx, rx,
            IntentFilter(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION), ContextCompat.RECEIVER_NOT_EXPORTED)
        registered = true
    }

    private class Listener(val ok: () -> Unit = {}, val fail: (Int) -> Unit = {}) : WifiP2pManager.ActionListener {
        override fun onSuccess() = ok()
        override fun onFailure(reason: Int) = fail(reason)
    }

    /** Receiver side. */
    fun host(keys: Keys) {
        register()
        mgr.removeGroup(ch, Listener({ create(keys, WifiP2pConfig.GROUP_OWNER_BAND_5GHZ) },
            { create(keys, WifiP2pConfig.GROUP_OWNER_BAND_5GHZ) }))
    }

    private fun create(keys: Keys, band: Int) {
        val cfg = WifiP2pConfig.Builder()
            .setNetworkName(keys.wifiName)
            .setPassphrase(keys.wifiPass)
            .enablePersistentMode(false)
            .setGroupOperatingBand(band)
            .build()
        mgr.createGroup(ch, cfg, Listener(
            { onStatus("Ready. Enter the code on the sender's phone.") },
            { r ->
                if (band != WifiP2pConfig.GROUP_OWNER_BAND_AUTO) create(keys, WifiP2pConfig.GROUP_OWNER_BAND_AUTO)
                else onStatus("Could not start Wi-Fi Direct (code $r). Turn Wi-Fi on and try again.")
            }))
    }

    /** Sender side. */
    fun join(keys: Keys) {
        register()
        val cfg = WifiP2pConfig.Builder().setNetworkName(keys.wifiName).setPassphrase(keys.wifiPass).build()
        mgr.connect(ch, cfg, Listener({
            onStatus("Connecting…")
            // If the link was already up no new broadcast arrives, so ask for it explicitly.
            main.postDelayed({ mgr.requestConnectionInfo(ch) { if (it.groupFormed) onConnected(it) } }, 2500)
        }, { r -> onStatus("Could not connect (code $r). Check the code and that the receiver is waiting.") }))
    }

    fun stop() {
        if (registered) {
            try { ctx.unregisterReceiver(rx) } catch (e: Exception) { }
        }
        registered = false
        main.removeCallbacksAndMessages(null)
        mgr.removeGroup(ch, null)
    }
}
