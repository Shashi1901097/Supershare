package com.supershare.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// ---------------------------------------------------------------------------------------------
// Theme: a calm blue Material 3 palette with proper light and dark variants. Flat surfaces, no gradients.
// ---------------------------------------------------------------------------------------------

private val BrandDark = darkColorScheme(
    primary = Color(0xFF8AB4F8), onPrimary = Color(0xFF062E6F),
    primaryContainer = Color(0xFF0842A0), onPrimaryContainer = Color(0xFFD3E3FD),
    secondary = Color(0xFFB4BCC9), onSecondary = Color(0xFF1C2430),
    secondaryContainer = Color(0xFF2A3342), onSecondaryContainer = Color(0xFFDCE3F0),
    tertiary = Color(0xFF81C995), onTertiary = Color(0xFF0B3A1B),
    tertiaryContainer = Color(0xFF1B4D2E), onTertiaryContainer = Color(0xFFC4EED0),
    error = Color(0xFFF2B8B5), onError = Color(0xFF601410),
    errorContainer = Color(0xFF8C1D18), onErrorContainer = Color(0xFFF9DEDC),
    background = Color(0xFF111318), onBackground = Color(0xFFE3E2E6),
    surface = Color(0xFF111318), onSurface = Color(0xFFE3E2E6),
    surfaceVariant = Color(0xFF44474F), onSurfaceVariant = Color(0xFFC4C6D0),
    outline = Color(0xFF8E9099), outlineVariant = Color(0xFF44474F),
    surfaceContainerLowest = Color(0xFF0C0E13), surfaceContainerLow = Color(0xFF191C20),
    surfaceContainer = Color(0xFF1D2024), surfaceContainerHigh = Color(0xFF282A2F),
    surfaceContainerHighest = Color(0xFF33353A)
)

private val BrandLight = lightColorScheme(
    primary = Color(0xFF0B57D0), onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD3E3FD), onPrimaryContainer = Color(0xFF041E49),
    secondary = Color(0xFF565F71), onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFDAE2F9), onSecondaryContainer = Color(0xFF131C2B),
    tertiary = Color(0xFF146C2E), onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFC4EED0), onTertiaryContainer = Color(0xFF00210B),
    error = Color(0xFFB3261E), onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFF9DEDC), onErrorContainer = Color(0xFF410E0B),
    background = Color(0xFFF8F9FC), onBackground = Color(0xFF1A1C1E),
    surface = Color(0xFFF8F9FC), onSurface = Color(0xFF1A1C1E),
    surfaceVariant = Color(0xFFE1E2EC), onSurfaceVariant = Color(0xFF44474F),
    outline = Color(0xFF74777F), outlineVariant = Color(0xFFC4C6D0),
    surfaceContainerLowest = Color(0xFFFFFFFF), surfaceContainerLow = Color(0xFFF2F3F9),
    surfaceContainer = Color(0xFFECEDF4), surfaceContainerHigh = Color(0xFFE6E8EE),
    surfaceContainerHighest = Color(0xFFE1E2E8)
)

@Composable
fun SuperTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) BrandDark else BrandLight, content = content)
}

fun fmtSize(b: Long): String {
    val u = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = 0
    while (v >= 1024 && i < 4) { v /= 1024; i++ }
    return if (i == 0) "$b B" else "%.1f %s".format(v, u[i])
}

fun fmtEta(s: Long): String = when {
    s < 0 -> "—"
    s < 60 -> "${s}s"
    else -> "${s / 60}m ${s % 60}s"
}

// ---------------------------------------------------------------------------------------------
// Building blocks
// ---------------------------------------------------------------------------------------------

@Composable
fun Screen(content: @Composable ColumnScope.() -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp, vertical = 8.dp), content = content)
    }
}

/** Small vector icons drawn directly, so the app needs no icon library. */
@Composable
fun AppIcon(kind: String, tint: Color, size: Dp = 24.dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        val w = s * 0.09f
        val st = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(x: Float, y: Float) = Offset(x * s, y * s)
        when (kind) {
            "up" -> {
                drawLine(tint, p(0.5f, 0.82f), p(0.5f, 0.18f), w, StrokeCap.Round)
                drawLine(tint, p(0.5f, 0.18f), p(0.24f, 0.44f), w, StrokeCap.Round)
                drawLine(tint, p(0.5f, 0.18f), p(0.76f, 0.44f), w, StrokeCap.Round)
            }
            "down" -> {
                drawLine(tint, p(0.5f, 0.18f), p(0.5f, 0.82f), w, StrokeCap.Round)
                drawLine(tint, p(0.5f, 0.82f), p(0.24f, 0.56f), w, StrokeCap.Round)
                drawLine(tint, p(0.5f, 0.82f), p(0.76f, 0.56f), w, StrokeCap.Round)
            }
            "back" -> drawPath(Path().apply { moveTo(0.62f * s, 0.2f * s); lineTo(0.34f * s, 0.5f * s); lineTo(0.62f * s, 0.8f * s) }, tint, style = st)
            "forward" -> drawPath(Path().apply { moveTo(0.38f * s, 0.2f * s); lineTo(0.66f * s, 0.5f * s); lineTo(0.38f * s, 0.8f * s) }, tint, style = st)
            "check" -> drawPath(Path().apply { moveTo(0.2f * s, 0.55f * s); lineTo(0.42f * s, 0.75f * s); lineTo(0.8f * s, 0.28f * s) }, tint, style = st)
            "folder" -> drawRoundRect(tint, topLeft = p(0.1f, 0.24f), size = Size(0.8f * s, 0.58f * s), cornerRadius = CornerRadius(0.08f * s), style = st)
            else -> drawRoundRect(tint, topLeft = p(0.22f, 0.12f), size = Size(0.56f * s, 0.76f * s), cornerRadius = CornerRadius(0.08f * s), style = st)
        }
    }
}

/** The app icon on its own dark tile (the ring has a light centre that needs a dark background). */
@Composable
fun LogoTile(dim: Dp) {
    Box(Modifier.size(dim).clip(RoundedCornerShape(dim * 0.24f)).background(Color(0xFF161635)), contentAlignment = Alignment.Center) {
        Image(painter = painterResource(R.drawable.logo_ring), contentDescription = "Super Share logo",
            contentScale = ContentScale.Fit, modifier = Modifier.size(dim * 0.78f))
    }
}

@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { AppIcon("back", MaterialTheme.colorScheme.onSurface) }
        Text(title, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, label ->
            FilterChip(
                selected = i == selected,
                onClick = { if (i != selected) onSelect(i) },
                label = { Text(label, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) },
                modifier = Modifier.weight(1f).height(40.dp)
            )
        }
    }
}

@Composable
fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
        Text(text, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun DangerButton(text: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error, contentColor = MaterialTheme.colorScheme.onError)) {
        Text(text, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun TonalButton(text: String, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(16.dp)) {
        Text(text, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun SmallButton(text: String, danger: Boolean = false, onClick: () -> Unit) {
    FilledTonalButton(
        onClick = onClick, modifier = Modifier.height(36.dp), contentPadding = PaddingValues(horizontal = 14.dp),
        colors = if (danger) ButtonDefaults.filledTonalButtonColors(
            containerColor = MaterialTheme.colorScheme.errorContainer, contentColor = MaterialTheme.colorScheme.onErrorContainer)
        else ButtonDefaults.filledTonalButtonColors()
    ) { Text(text, style = MaterialTheme.typography.labelMedium) }
}

@Composable
fun SurfaceCard(modifier: Modifier = Modifier, horizontalAlignment: Alignment.Horizontal = Alignment.Start,
                content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(16.dp), horizontalAlignment = horizontalAlignment, content = content)
    }
}

@Composable
fun ActionTile(title: String, icon: String, container: Color, content: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = container, contentColor = content)) {
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(content.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
                AppIcon(icon, content, 24.dp)
            }
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = modifier)
}

@Composable
fun Gauge(ui: UiState, dim: Dp) {
    val prog by animateFloatAsState(ui.progress, label = "progress")
    Box(Modifier.size(dim), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(
            progress = { prog }, modifier = Modifier.fillMaxSize(), strokeWidth = 10.dp,
            trackColor = MaterialTheme.colorScheme.surfaceContainerHighest, strokeCap = StrokeCap.Round
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("%.0f".format(ui.mbps), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.SemiBold)
            Text("Mbps", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Text("%.1f MB/s".format(ui.mbps / 8), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun StatColumn(label: String, value: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun Stats(ui: UiState) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 8.dp)) {
            StatColumn("Transferred", "${fmtSize(ui.done)} / ${fmtSize(ui.total)}", Modifier.weight(1.5f))
            StatColumn("Time left", fmtEta(ui.eta), Modifier.weight(1f))
            StatColumn("Peak", "%.0f Mbps".format(ui.peak), Modifier.weight(1f))
        }
    }
}

@Composable
fun FileBadge(name: String, folder: Boolean = false) {
    val ext = if (folder) "" else name.substringAfterLast('.', "").take(4).uppercase().ifEmpty { "FILE" }
    val fg = MaterialTheme.colorScheme.onSecondaryContainer
    Box(Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.secondaryContainer),
        contentAlignment = Alignment.Center) {
        if (folder) AppIcon("folder", fg, 22.dp)
        else Text(ext, style = MaterialTheme.typography.labelSmall, color = fg, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
fun FileRow(name: String, sub: String, modifier: Modifier = Modifier, trailing: @Composable () -> Unit = {}) {
    ListItem(
        modifier = modifier,
        headlineContent = { Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = { Text(sub) },
        leadingContent = { FileBadge(name) },
        trailingContent = trailing,
        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
    )
}
