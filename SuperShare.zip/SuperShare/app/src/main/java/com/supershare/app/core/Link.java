package com.supershare.app.core;

import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.security.GeneralSecurityException;
import java.util.Arrays;

/** An authenticated, encrypted connection. Every message travels as [length][AES-GCM sealed frame]. */
final class Link implements Closeable {
    final Socket socket;
    final DataInputStream in;
    final DataOutputStream out;
    final byte[] sessionId;
    final byte[] sessionKey;
    private final Crypto.FrameCipher tx;
    private final Crypto.FrameCipher rx;
    private byte[] ct = new byte[0];

    Link(Socket socket, DataInputStream in, DataOutputStream out, byte[] sessionId, byte[] sessionKey,
         byte[] connNonce, boolean server) throws IOException {
        this.socket = socket; this.in = in; this.out = out;
        this.sessionId = sessionId; this.sessionKey = sessionKey;
        byte[] c2s = Crypto.derive(sessionKey, "c2s", connNonce);
        byte[] s2c = Crypto.derive(sessionKey, "s2c", connNonce);
        try {
            this.tx = new Crypto.FrameCipher(server ? s2c : c2s, true);
            this.rx = new Crypto.FrameCipher(server ? c2s : s2c, false);
        } catch (GeneralSecurityException e) {
            throw new IOException("Encryption is not available");
        }
    }

    void send(byte[] plain, int off, int len) throws IOException {
        if (ct.length < len + 16) ct = new byte[len + 16];
        int n;
        try { n = tx.seal(plain, off, len, ct); }
        catch (GeneralSecurityException e) { throw new IOException("Encryption failed"); }
        out.writeInt(n);
        out.write(ct, 0, n);
        out.flush();
    }

    /** Reads one frame into dst (needs maxPlain + 16 bytes of room). Returns the plain length. */
    int recv(byte[] dst, int maxPlain) throws IOException {
        int n = in.readInt();
        if (n < 16 || n > maxPlain + 16) throw new IOException("Bad frame size");
        if (ct.length < n) ct = new byte[n];
        in.readFully(ct, 0, n);
        try { return rx.open(ct, n, dst); }
        catch (GeneralSecurityException e) { throw new IOException("Corrupted or tampered data"); }
    }

    byte[] recv(int maxPlain) throws IOException {
        int n = in.readInt();
        if (n < 16 || n > maxPlain + 16) throw new IOException("Bad frame size");
        byte[] c = new byte[n];
        in.readFully(c, 0, n);
        byte[] dst = new byte[n];
        try { return Arrays.copyOf(dst, rx.open(c, n, dst)); }
        catch (GeneralSecurityException e) { throw new IOException("Corrupted or tampered data"); }
    }

    @Override public void close() {
        try { socket.close(); } catch (IOException ignored) {}
    }
}
