package com.supershare.app.core;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;

/**
 * SRP-6a password-authenticated key exchange (2048-bit safe prime from RFC 3526 group 14, g = 2, SHA-256).
 * Both sides end up with the same strong session key only if they used the same code. An eavesdropper who
 * records the whole conversation learns nothing that lets him test code guesses offline; every guess
 * needs a live attempt, and the receiver locks out after a few wrong ones.
 */
public final class Srp {
    private Srp() {}

    static final BigInteger N = new BigInteger("ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aacaa68ffffffffffffffff", 16);
    static final BigInteger G = BigInteger.valueOf(2);
    static final int LEN = 256;                                       // bytes of N
    private static final BigInteger KMULT = hashInt(pad(N), pad(G));  // k = H(N | PAD(g))

    static byte[] pad(BigInteger v) {
        byte[] raw = v.toByteArray();
        byte[] out = new byte[LEN];
        int copy = Math.min(raw.length, LEN);
        System.arraycopy(raw, raw.length - copy, out, LEN - copy, copy);
        return out;
    }

    static byte[] sha256(byte[]... parts) {
        try {
            MessageDigest d = MessageDigest.getInstance("SHA-256");
            for (byte[] p : parts) d.update(p);
            return d.digest();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }

    private static BigInteger hashInt(byte[]... parts) { return new BigInteger(1, sha256(parts)); }

    public static byte[] newSalt(SecureRandom rnd) {
        byte[] s = new byte[16];
        rnd.nextBytes(s);
        return s;
    }

    private static BigInteger x(String code, byte[] salt) {
        byte[] inner = sha256(("supershare:" + code).getBytes(StandardCharsets.UTF_8));
        return hashInt(salt, inner);
    }

    public static BigInteger verifier(String code, byte[] salt) {
        return G.modPow(x(code, salt), N);
    }

    private static BigInteger randomExponent(SecureRandom rnd) {
        BigInteger e;
        do { e = new BigInteger(256, rnd); } while (e.bitLength() < 200);
        return e;
    }

    /** A public value must be in 2 .. N-2 (rules out 0, 1 and N-1, which would leak or fix the key). */
    private static boolean validPublic(BigInteger v) {
        return v.compareTo(BigInteger.ONE) > 0 && v.compareTo(N.subtract(BigInteger.ONE)) < 0;
    }

    public static final class Client {
        private final String code;
        private final BigInteger a;
        private final BigInteger bigA;

        public Client(String code, SecureRandom rnd) {
            this.code = code;
            this.a = randomExponent(rnd);
            this.bigA = G.modPow(a, N);
        }

        public byte[] publicA() { return pad(bigA); }

        public byte[] sessionKey(byte[] salt, byte[] bBytes) throws GeneralSecurityException {
            BigInteger bigB = new BigInteger(1, bBytes);
            if (!validPublic(bigB)) throw new GeneralSecurityException("Invalid server value");
            BigInteger u = hashInt(pad(bigA), pad(bigB));
            if (u.signum() == 0) throw new GeneralSecurityException("Invalid server value");
            BigInteger x = x(code, salt);
            BigInteger base = bigB.subtract(KMULT.multiply(G.modPow(x, N))).mod(N);
            BigInteger s = base.modPow(a.add(u.multiply(x)), N);
            return sha256(pad(s));
        }
    }

    public static final class Server {
        private final BigInteger v;
        private final BigInteger b;
        private final BigInteger bigB;

        public Server(BigInteger verifier, SecureRandom rnd) {
            this.v = verifier;
            this.b = randomExponent(rnd);
            this.bigB = KMULT.multiply(v).add(G.modPow(b, N)).mod(N);
        }

        public byte[] publicB() { return pad(bigB); }

        public byte[] sessionKey(byte[] aBytes) throws GeneralSecurityException {
            BigInteger bigA = new BigInteger(1, aBytes);
            if (!validPublic(bigA)) throw new GeneralSecurityException("Invalid client value");
            BigInteger u = hashInt(pad(bigA), pad(bigB));
            if (u.signum() == 0) throw new GeneralSecurityException("Invalid client value");
            BigInteger s = bigA.multiply(v.modPow(u, N)).mod(N).modPow(b, N);
            if (!validPublic(s)) throw new GeneralSecurityException("Weak shared value");
            return sha256(pad(s));
        }
    }
}
