package com.supershare.app.core;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.security.SecureRandom;
import java.util.BitSet;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Receives files. A sender must log in with the 6-digit code through an SRP key exchange; everything after
 * that is AES-GCM encrypted and authenticated. All sizes/names/indexes from the peer are validated, files that
 * do not fit into the free space are refused (and reported), and progress is saved per 4 MB chunk so a
 * transfer can resume.
 */
public final class Receiver {
    private static final class FileState {
        final String id, name;
        final long size;
        final int chunks;
        final BitSet bits;
        final Target target;
        final AtomicBoolean done = new AtomicBoolean(false);

        FileState(String id, String name, long size, BitSet bits, Target target) {
            this.id = id; this.name = name; this.size = size;
            this.chunks = Protocol.chunksOf(size);
            this.bits = bits; this.target = target;
        }
    }

    private static final class Sess {
        final byte[] key;
        final long created = System.nanoTime();
        Sess(byte[] key) { this.key = key; }
    }

    private final byte[] salt;
    private final BigInteger verifier;
    private final TargetFactory factory;
    private final ReceiverEvents ev;
    private final Map<String, FileState> states = new ConcurrentHashMap<>();
    private final Map<String, Sess> sessions = new ConcurrentHashMap<>();
    private final Set<Socket> open = ConcurrentHashMap.newKeySet();
    private final AtomicLong batchDone = new AtomicLong();
    private volatile long batchTotal = 0;
    private final AtomicInteger authFailures = new AtomicInteger();
    private final Semaphore slots = new Semaphore(Protocol.MAX_CONNECTIONS);
    private final Semaphore handshakes = new Semaphore(Protocol.MAX_HANDSHAKES);
    private final SecureRandom rnd = new SecureRandom();
    private ServerSocket server;
    private ExecutorService pool;

    public Receiver(String code, TargetFactory factory, ReceiverEvents ev) {
        if (!Keys.isValid(code)) throw new IllegalArgumentException("Invalid code");
        this.salt = Srp.newSalt(rnd);
        this.verifier = Srp.verifier(code, salt);
        this.factory = factory;
        this.ev = ev;
    }

    public int authFailures() { return authFailures.get(); }

    /** Starts listening. bind == null means all interfaces. Returns the port actually used. */
    public synchronized int start(int port, InetAddress bind) throws IOException {
        server = new ServerSocket();
        server.setReuseAddress(true);
        server.bind(new java.net.InetSocketAddress(bind, port), 64);
        pool = Executors.newCachedThreadPool();
        final ServerSocket srv = server;
        pool.execute(() -> {
            while (!srv.isClosed()) {
                final Socket s;
                try { s = srv.accept(); } catch (IOException e) { break; }
                if (!slots.tryAcquire()) { closeQuietly(s); continue; }
                open.add(s);
                try {
                    pool.execute(() -> {
                        try { handle(s); }
                        catch (IOException | RuntimeException ignored) { /* peer dropped; progress is saved */ }
                        finally { open.remove(s); closeQuietly(s); slots.release(); }
                    });
                } catch (RuntimeException rejected) {
                    open.remove(s); closeQuietly(s); slots.release();
                }
            }
        });
        return server.getLocalPort();
    }

    public synchronized void stop() {
        if (server != null) { try { server.close(); } catch (IOException ignored) {} }
        for (Socket s : open) closeQuietly(s);
        if (pool != null) {
            pool.shutdownNow();
            try { pool.awaitTermination(3, TimeUnit.SECONDS); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
        for (FileState f : states.values()) { saveBits(f); f.target.close(); }   // progress is saved before we return
        sessions.clear();
    }

    private static void closeQuietly(Socket s) { try { s.close(); } catch (IOException ignored) {} }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    private void handle(Socket s) throws IOException {
        s.setTcpNoDelay(true);
        s.setSoTimeout(Protocol.PRE_AUTH_TIMEOUT_MS);
        try { s.setReceiveBufferSize(8 << 20); } catch (java.net.SocketException ignored) {}
        DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream(), 8192));
        DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));

        byte[] nonce = new byte[16];
        rnd.nextBytes(nonce);
        out.write(nonce);
        out.flush();

        byte type = in.readByte();
        if (type == Protocol.T_QUERY) {
            if (authFailures.get() >= Protocol.MAX_AUTH_FAILURES) return;      // locked out: no more guesses
            if (!handshakes.tryAcquire()) return;
            Link link;
            try { link = Handshake.serverQuery(s, in, out, nonce, salt, verifier, rnd); }
            finally { handshakes.release(); }
            if (link == null) { ev.onAuthFailed(authFailures.incrementAndGet()); return; }
            if (sessions.size() >= Protocol.MAX_SESSIONS) pruneSessions();
            sessions.put(hex(link.sessionId), new Sess(link.sessionKey));
            s.setSoTimeout(Protocol.SERVER_TIMEOUT_MS);
            query(link);
        } else if (type == Protocol.T_DATA) {
            byte[] sid = new byte[8];
            byte[] proof = new byte[Handshake.PROOF];
            in.readFully(sid);
            in.readFully(proof);
            Sess se = sessions.get(hex(sid));
            if (se == null) return;
            if (!Crypto.equal(Crypto.hmac(se.key, "DATA", nonce, sid), proof)) return;
            s.setSoTimeout(Protocol.SERVER_TIMEOUT_MS);
            data(Handshake.serverData(s, in, out, nonce, sid, se.key));
        }
    }

    private void pruneSessions() {
        String oldest = null; long t = Long.MAX_VALUE;
        for (Map.Entry<String, Sess> e : sessions.entrySet())
            if (e.getValue().created < t) { t = e.getValue().created; oldest = e.getKey(); }
        if (oldest != null) sessions.remove(oldest);
    }

    private FileState openState(String id, String name, long size) throws IOException {
        synchronized (states) {
            FileState f = states.get(id);
            if (f != null) return f;
            Target t = factory.open(id, name, size);
            BitSet b = t.loadBits();
            if (b == null) b = new BitSet();
            f = new FileState(id, name, size, b, t);
            states.put(id, f);
            return f;
        }
    }

    private void query(Link link) throws IOException {
        byte[] plain = link.recv(Protocol.MAX_QUERY_PLAIN);
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(plain));
        int n = in.readInt();
        if (n < 0 || n > Protocol.MAX_FILES) return;
        String[] ids = new String[n];
        String[] names = new String[n];
        long[] sizes = new long[n];
        Set<String> seen = new HashSet<>();
        long totalChunks = 0;
        for (int i = 0; i < n; i++) {
            ids[i] = in.readUTF();
            if (!Protocol.validId(ids[i]) || !seen.add(ids[i])) return;
            names[i] = Names.sanitize(in.readUTF());
            sizes[i] = in.readLong();
            if (sizes[i] < 0 || sizes[i] > Protocol.MAX_FILE_SIZE) return;
            totalChunks += Protocol.chunksOf(sizes[i]);
            if (totalChunks > Protocol.MAX_TOTAL_CHUNKS) return;       // memory-exhaustion guard
        }

        long free = factory.freeBytes();
        long budget = free - Protocol.RESERVE_BYTES;
        byte[] status = new byte[n];
        long[] need = new long[n];
        BitSet[] bits = new BitSet[n];
        long total = 0, done = 0;
        int blocked = 0;
        long maxNeed = 0;
        String firstBlocked = "";

        for (int i = 0; i < n; i++) {
            total += sizes[i];
            int chunks = Protocol.chunksOf(sizes[i]);
            if (factory.alreadyHave(ids[i], sizes[i])) {
                BitSet all = new BitSet();
                all.set(0, chunks);
                bits[i] = all;
                status[i] = Protocol.S_HAVE;
                done += sizes[i];
                continue;
            }
            FileState f = states.get(ids[i]);
            BitSet b;
            if (f != null) { synchronized (f.bits) { b = (BitSet) f.bits.clone(); } }
            else { BitSet p = factory.peekBits(ids[i], sizes[i]); b = (p == null) ? new BitSet() : p; }
            long have = Protocol.doneBytes(b, sizes[i]);
            long remaining = sizes[i] - have;

            if (remaining == 0 || remaining <= budget) {
                budget -= remaining;
                f = openState(ids[i], names[i], sizes[i]);
                synchronized (f.bits) { b = (BitSet) f.bits.clone(); }
                have = Protocol.doneBytes(b, sizes[i]);
                bits[i] = b;
                done += have;
                status[i] = Protocol.S_ACCEPT;
                if (f.chunks == 0 || b.get(0, f.chunks).cardinality() == f.chunks) finish(f);
            } else {
                bits[i] = b;
                done += have;
                status[i] = Protocol.S_NO_SPACE;
                need[i] = remaining - Math.max(budget, 0);
                blocked++;
                if (need[i] > maxNeed) maxNeed = need[i];
                if (firstBlocked.isEmpty()) firstBlocked = names[i];
            }
        }
        batchTotal = total;
        batchDone.set(done);
        ev.onBatch(done, total, blocked, maxNeed, firstBlocked);
        ev.onProgress(done, total);

        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bo);
        out.writeLong(free);
        out.writeInt(n);
        for (int i = 0; i < n; i++) {
            out.writeByte(status[i]);
            out.writeLong(need[i]);
            byte[] b = bits[i].toByteArray();
            out.writeInt(b.length);
            out.write(b);
        }
        if (bo.size() > Protocol.MAX_QUERY_PLAIN) return;
        link.send(bo.toByteArray(), 0, bo.size());
    }

    private void data(Link link) throws IOException {
        byte[] hdr = link.recv(1024);
        DataInputStream h = new DataInputStream(new ByteArrayInputStream(hdr));
        String id = h.readUTF();
        int start = h.readInt();
        int count = h.readInt();
        FileState f = states.get(id);
        if (f == null || f.done.get()) return;
        if (start < 0 || count <= 0 || start >= f.chunks || (long) start + count > f.chunks) return;

        long offset = (long) start * Protocol.CHUNK;
        long end = Math.min(offset + (long) count * Protocol.CHUNK, f.size);
        ev.onFileStart(f.name);
        byte[] buf = new byte[Protocol.DATA_FRAME + 16];
        long pos = offset;
        int marked = start;
        long lastSave = System.nanoTime();
        boolean ok = false;
        try {
            while (pos < end) {
                int n = link.recv(buf, Protocol.DATA_FRAME);        // decrypts and verifies; throws if altered
                if (n <= 0 || n > end - pos) throw new IOException("Bad data block");
                f.target.write(pos, ByteBuffer.wrap(buf, 0, n));
                pos += n;
                ev.onProgress(batchDone.addAndGet(n), batchTotal);
                int doneChunks = (pos >= f.size) ? f.chunks : (int) (pos / Protocol.CHUNK);
                while (marked < doneChunks) { synchronized (f.bits) { f.bits.set(marked); } marked++; }
                if (System.nanoTime() - lastSave > 2_000_000_000L) { saveBits(f); lastSave = System.nanoTime(); }
            }
            ok = pos >= end;
        } finally {
            saveBits(f);
            boolean all;
            synchronized (f.bits) { all = f.bits.get(0, f.chunks).cardinality() == f.chunks; }
            if (all) finish(f);
        }
        if (ok) link.send(new byte[]{1}, 0, 1);            // authenticated confirmation: this range is safely stored
    }

    private void saveBits(FileState f) {
        if (f.done.get()) return;
        BitSet c;
        synchronized (f.bits) { c = (BitSet) f.bits.clone(); }
        try { f.target.saveBits(c); } catch (RuntimeException ignored) {}
    }

    private void finish(FileState f) throws IOException {
        if (!f.done.compareAndSet(false, true)) return;
        states.remove(f.id);
        f.target.finish();
        ev.onFileDone(f.name);
    }
}
