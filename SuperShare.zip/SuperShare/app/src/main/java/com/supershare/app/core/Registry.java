package com.supershare.app.core;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;

/**
 * Group share: the sender hosts the Wi-Fi Direct group and runs this small "guest list". Every phone that
 * joined announces its name and the port of its receiver here, so the sender can see who is there and
 * send to all of them at the same time. The guest list only decides who is shown; files are only ever
 * accepted by a receiver that completes the code-protected login.
 */
public final class Registry {
    public static final int MAGIC = 0x53534852;
    public static final int MAX_DEVICES = 8;
    static volatile long freshNanos = 15_000_000_000L;       // a device that has not re-announced for this long disappears

    public static final class Device {
        public final String ip;
        public final String name;
        public final int port;
        final long seen;
        Device(String ip, String name, int port, long seen) { this.ip = ip; this.name = name; this.port = port; this.seen = seen; }
    }

    private final Map<String, Device> devices = new ConcurrentHashMap<>();
    private final Semaphore slots = new Semaphore(16);
    private ServerSocket server;
    private ExecutorService pool;

    public synchronized int start(int port, InetAddress bind) throws IOException {
        server = new ServerSocket();
        server.setReuseAddress(true);
        server.bind(new InetSocketAddress(bind, port), 32);
        pool = Executors.newCachedThreadPool();
        final ServerSocket srv = server;
        pool.execute(() -> {
            while (!srv.isClosed()) {
                final Socket s;
                try { s = srv.accept(); } catch (IOException e) { break; }
                if (!slots.tryAcquire()) { close(s); continue; }
                try {
                    pool.execute(() -> {
                        try { handle(s); } catch (IOException | RuntimeException ignored) {}
                        finally { close(s); slots.release(); }
                    });
                } catch (RuntimeException rejected) { close(s); slots.release(); }
            }
        });
        return server.getLocalPort();
    }

    public synchronized void stop() {
        if (server != null) { try { server.close(); } catch (IOException ignored) {} }
        if (pool != null) pool.shutdownNow();
        devices.clear();
    }

    /** Devices that announced themselves recently. */
    public List<Device> devices() {
        prune();
        List<Device> list = new ArrayList<>(devices.values());
        Collections.sort(list, new Comparator<Device>() {
            @Override public int compare(Device a, Device b) {
                int c = a.name.compareToIgnoreCase(b.name);
                return c != 0 ? c : a.ip.compareTo(b.ip);
            }
        });
        return list;
    }

    private void prune() {
        long now = System.nanoTime();
        for (Map.Entry<String, Device> e : devices.entrySet())
            if (now - e.getValue().seen > freshNanos) devices.remove(e.getKey());
    }

    private static void close(Socket s) { try { s.close(); } catch (IOException ignored) {} }

    static String clean(String raw) {
        if (raw == null) return "Phone";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < raw.length() && b.length() < 40; i++) {
            char c = raw.charAt(i);
            if (c >= 0x20 && c != 0x7f && c != '<' && c != '>') b.append(c);
        }
        String s = b.toString().trim();
        return s.isEmpty() ? "Phone" : s;
    }

    private void handle(Socket s) throws IOException {
        s.setSoTimeout(3000);
        DataInputStream in = new DataInputStream(s.getInputStream());
        DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
        if (in.readInt() != MAGIC) return;
        if (in.readByte() != 1) return;
        String name = clean(in.readUTF());
        int port = in.readInt();
        if (port < 1 || port > 65535) return;
        InetAddress a = ((InetSocketAddress) s.getRemoteSocketAddress()).getAddress();
        String ip = a.getHostAddress();
        if (!devices.containsKey(ip) && devices.size() >= MAX_DEVICES) {
            prune();
            if (devices.size() >= MAX_DEVICES) { out.writeByte(0); out.flush(); return; }
        }
        devices.put(ip, new Device(ip, name, port, System.nanoTime()));
        out.writeByte(1);
        out.flush();
    }

    /** Called by a phone that joined the group: "I am here, my receiver listens on myPort". */
    public static void register(String host, int registryPort, String name, int myPort) throws IOException {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, registryPort), 5000);
            s.setSoTimeout(3000);
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
            out.writeInt(MAGIC);
            out.writeByte(1);
            out.writeUTF(clean(name));
            out.writeInt(myPort);
            out.flush();
            if (s.getInputStream().read() != 1) throw new IOException("The sender did not accept this device");
        }
    }
}
