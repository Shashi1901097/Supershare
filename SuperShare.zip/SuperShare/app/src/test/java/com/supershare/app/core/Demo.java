package com.supershare.app.core;

import java.io.File;
import java.net.InetAddress;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/** A scripted walk-through of Super Share using the real engine and simulated phones (loopback + throttled link). */
public class Demo {
    static final long MB = 1L << 20;
    static long t0 = System.nanoTime();

    static void say(String s) { System.out.printf("[%5.1fs] %s%n", (System.nanoTime() - t0) / 1e9, s); }
    static void head(String s) { System.out.println("\n==== " + s + " ===="); t0 = System.nanoTime(); }
    static String mb(long b) { return String.format("%.0f MB", b / 1048576.0); }
    static String bar(double f) { int n = (int) Math.round(f * 20); StringBuilder b = new StringBuilder(); for (int i = 0; i < 20; i++) b.append(i < n ? '█' : '░'); return b.toString(); }

    /** Prints a progress line every 0.6 s until stopped. */
    static Thread watch(final String label, final AtomicLong done, final AtomicLong total, final AtomicBoolean stop) {
        Thread t = new Thread(() -> {
            long last = 0, lastT = System.nanoTime();
            while (!stop.get()) {
                try { Thread.sleep(600); } catch (InterruptedException e) { return; }
                long d = done.get(), tt = Math.max(1, total.get()), now = System.nanoTime();
                double mbps = (d - last) * 8 / 1e6 / ((now - lastT) / 1e9);
                last = d; lastT = now;
                if (!stop.get()) say(String.format("  %-16s %s %3d%%  %s / %s  %4.0f Mbps", label, bar((double) d / tt), d * 100 / tt, mb(d), mb(tt), mbps));
            }
        });
        t.setDaemon(true); t.start();
        return t;
    }

    static Progress into(final AtomicLong done, final AtomicLong total) { return (d, t) -> { done.set(d); total.set(t); }; }

    static List<Source> files(File dir, Object... spec) throws Exception {
        List<Source> l = new ArrayList<>();
        long seed = 1;
        for (int i = 0; i < spec.length; i += 2) l.add(new CoreTests.FileSource(CoreTests.makeFile(dir, (String) spec[i], ((Number) spec[i + 1]).longValue(), seed++)));
        return l;
    }

    static void verify(CoreTests.DirFactory fac, List<Source> files) throws Exception {
        int ok = 0;
        for (Source s : files) if (CoreTests.sha(fac.out(s.name())).equals(CoreTests.sha(((CoreTests.FileSource) s).f))) ok++;
        say("✔ checked every file byte-by-byte: " + ok + " of " + files.size() + " identical");
    }

    // ---------------------------------------------------------------------------------------------
    static void one() throws Exception {
        head("1. One phone to one phone (6-digit code, all file types, Wi-Fi link limited to ~480 Mbps)");
        String code = Keys.newCode();
        File src = CoreTests.tmp("phoneA");
        CoreTests.DirFactory fac = new CoreTests.DirFactory(CoreTests.tmp("phoneB"));
        fac.rate = 60L * MB;
        say("Phone B taps Receive. Screen shows code  " + Keys.pretty(code));
        Receiver rx = new Receiver(code, fac, new CoreTests.Rec());
        int port = rx.start(0, InetAddress.getLoopbackAddress());
        say("Phone B: private Wi-Fi Direct group is up, waiting...");
        List<Source> files = files(src, "Holiday.mp4", 60 * MB, "backup.tar.gz", 30 * MB, "app-release.apk", 12 * MB,
                "family-photos.zip", 40 * MB, "tickets.pdf", 2 * MB);
        long total = 0; for (Source s : files) total += s.size();
        say("Phone A: chose 5 files (" + mb(total) + "): .mp4 .tar.gz .apk .zip .pdf  — then typed code " + Keys.pretty(code));
        AtomicLong d = new AtomicLong(), t = new AtomicLong(); AtomicBoolean stop = new AtomicBoolean();
        watch("Phone A -> B", d, t, stop);
        long s0 = System.nanoTime();
        Sender.Result r = Sender.send("127.0.0.1", port, code, files, into(d, t), new AtomicBoolean(false));
        stop.set(true); Thread.sleep(100);
        double sec = (System.nanoTime() - s0) / 1e9;
        say(String.format("Done ✓ %s in %.1f s  (average %.0f Mbps)", mb(total), sec, total * 8 / 1e6 / sec));
        verify(fac, files);
        rx.stop();
    }

    static void lowStorage() throws Exception {
        head("2. Receiver is short of storage (like 4 GB sent to a phone with 3.5 GB free, scaled down)");
        String code = Keys.newCode();
        File src = CoreTests.tmp("phoneA");
        CoreTests.DirFactory fac = new CoreTests.DirFactory(CoreTests.tmp("phoneB"));
        CoreTests.makeFile(fac.out, "old-movie.mkv", 120 * MB, 99);                 // something old on the receiver
        fac.free.set(Protocol.RESERVE_BYTES + 150 * MB);
        fac.rate = 120L * MB;
        CoreTests.Rec rec = new CoreTests.Rec();
        Receiver rx = new Receiver(code, fac, rec);
        int port = rx.start(0, InetAddress.getLoopbackAddress());
        List<Source> files = files(src, "video-1.zip", 100 * MB, "video-2.zip", 100 * MB);
        say("Phone B has " + mb(fac.free.get() - Protocol.RESERVE_BYTES) + " usable space. Phone A sends 2 files of 100 MB (200 MB).");
        AtomicLong d = new AtomicLong(), t = new AtomicLong();
        Sender.Result r = Sender.send("127.0.0.1", port, code, files, into(d, t), new AtomicBoolean(false));
        say("video-1.zip received ✔   complete=" + r.complete);
        say("Phone B shows:  ⚠ Insufficient storage — not enough room for video-2.zip. Free up " + mb(r.needMore) + " to continue.");
        say("Phone A shows:  Receiver has insufficient storage. Waiting for " + mb(r.needMore) + " more space…");
        Thread.sleep(1500);
        say("Phone B: user opens Free up space, deletes old-movie.mkv (120 MB)");
        new File(fac.out, "old-movie.mkv").delete();
        fac.free.addAndGet(120 * MB);
        say("Phone A retries automatically…");
        r = Sender.send("127.0.0.1", port, code, files, into(d, t), new AtomicBoolean(false));
        say("Done ✓ complete=" + r.complete + "  (video-1.zip was not sent again: " + r.haveCount + " already there)");
        verify(fac, files);
        rx.stop();
    }

    static void resume() throws Exception {
        head("3. Wi-Fi drops halfway — it continues where it stopped");
        String code = Keys.newCode();
        File src = CoreTests.tmp("phoneA");
        CoreTests.DirFactory fac = new CoreTests.DirFactory(CoreTests.tmp("phoneB"));
        fac.rate = 80L * MB;
        List<Source> files = files(src, "wedding-video.mp4", 200 * MB);
        final CoreTests.Rec rec = new CoreTests.Rec();
        final Receiver rx = new Receiver(code, fac, rec);
        int port = rx.start(0, InetAddress.getLoopbackAddress());
        final AtomicBoolean cut = new AtomicBoolean();
        rec.hook = x -> { if (x >= 90 * MB && !cut.getAndSet(true)) { say("  *** Wi-Fi connection lost at " + mb(x) + " ***"); new Thread(rx::stop).start(); } };
        AtomicLong d = new AtomicLong(), t = new AtomicLong(); AtomicBoolean stop = new AtomicBoolean();
        watch("Phone A -> B", d, t, stop);
        try { Sender.send("127.0.0.1", port, code, files, into(d, t), new AtomicBoolean(false)); }
        catch (Exception e) { say("Phone A: connection dropped → will resume ("+ e.getMessage() + ")"); }
        stop.set(true); Thread.sleep(300);
        BitSet saved = fac.peekBits(files.get(0).id(), files.get(0).size());
        say("Phone B kept " + saved.cardinality() * 4 + " MB of finished 4 MB pieces; nothing half-finished is shown to the user");
        fac.rate = 80L * MB;
        Receiver rx2 = new Receiver(code, fac, new CoreTests.Rec());
        int port2 = rx2.start(0, InetAddress.getLoopbackAddress());
        say("Wi-Fi back. Phone A taps Send again…");
        final long[] first = {-1};
        AtomicBoolean stop2 = new AtomicBoolean(); AtomicLong d2 = new AtomicLong(), t2 = new AtomicLong();
        watch("Phone A -> B", d2, t2, stop2);
        Sender.send("127.0.0.1", port2, code, files, (x, y) -> { if (first[0] < 0) { first[0] = x; say("  resuming from " + mb(x) + " (not from zero)"); } d2.set(x); t2.set(y); }, new AtomicBoolean(false));
        stop2.set(true); Thread.sleep(100);
        say("Done ✓");
        verify(fac, files);
        rx2.stop();
    }

    static void group() throws Exception {
        head("4. Group share: one sender, three phones at the same time");
        String code = Keys.newCode();
        File src = CoreTests.tmp("sender");
        Registry reg = new Registry();
        int regPort = reg.start(0, InetAddress.getLoopbackAddress());
        say("Sender chose Send > Group. Group code  " + Keys.pretty(code) + "   (guest list is open)");
        String[] names = {"Ravi's phone", "Mom's phone", "Anu's phone"};
        Receiver[] rxs = new Receiver[3]; CoreTests.DirFactory[] facs = new CoreTests.DirFactory[3];
        for (int i = 0; i < 3; i++) {
            facs[i] = new CoreTests.DirFactory(CoreTests.tmp("guest" + i));
            facs[i].rate = 45L * MB;
            rxs[i] = new Receiver(code, facs[i], new CoreTests.Rec());
            int p = rxs[i].start(0, null);
            CoreTests.rawRegister("127.0.0." + (2 + i), regPort, Registry.MAGIC, names[i], p);
            say(names[i] + " typed the code and joined");
        }
        List<Registry.Device> devs = reg.devices();
        StringBuilder sb = new StringBuilder("Sender sees " + devs.size() + " phones: ");
        for (Registry.Device dv : devs) sb.append(dv.name).append("  ");
        say(sb.toString());
        List<Source> files = files(src, "Family-trip.mp4", 50 * MB, "Photos.zip", 20 * MB);
        say("Sender taps  Send to 3 phones  (70 MB each)");
        final AtomicLong[] done = new AtomicLong[3], tot = new AtomicLong[3]; final AtomicBoolean stop = new AtomicBoolean();
        List<Thread> th = new ArrayList<>();
        for (int i = 0; i < devs.size(); i++) {
            final Registry.Device dv = devs.get(i); done[i] = new AtomicLong(); tot[i] = new AtomicLong();
            watch(dv.name, done[i], tot[i], stop);
            final int k = i;
            Thread t = new Thread(() -> { try { Sender.send(dv.ip, dv.port, code, files, into(done[k], tot[k]), new AtomicBoolean(false), 3); } catch (Exception e) { say("ERR " + e); } });
            th.add(t); t.start();
        }
        for (Thread t : th) t.join();
        stop.set(true); Thread.sleep(100);
        say("Done ✓ all three phones finished");
        for (int i = 0; i < 3; i++) { say(names[i] + ":"); verify(facs[i], files); }
        for (Receiver r : rxs) r.stop();
        reg.stop();
    }

    static void security() throws Exception {
        head("5. Someone tries to cheat");
        String code = Keys.newCode();
        File src = CoreTests.tmp("phoneA");
        CoreTests.DirFactory fac = new CoreTests.DirFactory(CoreTests.tmp("phoneB"));
        CoreTests.Rec rec = new CoreTests.Rec();
        Receiver rx = new Receiver(code, fac, rec);
        int port = rx.start(0, InetAddress.getLoopbackAddress());
        List<Source> files = files(src, "private-documents.zip", 20 * MB);
        say("Phone B is waiting with code " + Keys.pretty(code));
        String wrong = code.equals("000000") ? "111111" : "000000";
        try { Sender.send("127.0.0.1", port, wrong, files, (a, b) -> {}, new AtomicBoolean(false)); say("!! wrong code accepted"); }
        catch (Exception e) { say("Attacker guesses code " + Keys.pretty(wrong) + " → REJECTED (" + e.getMessage() + "); failed attempts so far: " + rx.authFailures()); }
        CoreTests.Proxy p = new CoreTests.Proxy(port);
        p.flipAfter = 3 * MB;
        say("Someone in the middle flips ONE bit of the data while it travels…");
        try { Sender.send("127.0.0.1", p.port(), code, files, (a, b) -> {}, new AtomicBoolean(false)); say("!! tampering not noticed"); }
        catch (Exception e) { say("Tampering detected → transfer stopped (" + e.getMessage() + "); damaged file published? " + fac.out("private-documents.zip").exists()); }
        p.flipAfter = -1;
        Sender.send("127.0.0.1", port, code, files, (a, b) -> {}, new AtomicBoolean(false));
        say("Clean retry finished ✓");
        verify(fac, files);
        byte[] seen = p.captured();
        say("An eavesdropper recorded " + seen.length / 1024 + " KB on the air: file name visible? " + (CoreTests.indexOf(seen, "private-documents".getBytes()) >= 0) + ", code visible? " + (CoreTests.indexOf(seen, code.getBytes()) >= 0));
        for (int i = 0; i < Protocol.MAX_AUTH_FAILURES; i++) { try { Sender.send("127.0.0.1", port, wrong, files, (a, b) -> {}, new AtomicBoolean(false)); } catch (Exception ignored) {} }
        try { Sender.send("127.0.0.1", port, code, files, (a, b) -> {}, new AtomicBoolean(false)); say("!! still open"); }
        catch (Exception e) { say("After " + rx.authFailures() + " wrong tries the receiver locks: even the right code is refused now (" + e.getMessage() + ")"); }
        p.close(); rx.stop();
    }

    public static void main(String[] a) throws Exception {
        String which = a.length > 0 ? a[0] : "all";
        if (which.equals("all") || which.equals("1")) one();
        if (which.equals("all") || which.equals("2")) lowStorage();
        if (which.equals("all") || which.equals("3")) resume();
        if (which.equals("all") || which.equals("4")) group();
        if (which.equals("all") || which.equals("5")) security();
        CoreTests.cleanup();
        System.exit(0);
    }
}
