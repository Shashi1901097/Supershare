package com.supershare.app.core;

import java.io.*;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Tests the real sender/receiver code over loopback TCP: integrity, encryption, names, resume, wrong codes,
 * lock-out, replay, tampering, eavesdropping, fuzzing, flooding, storage limits. Plain JDK so it runs anywhere
 * (also as JUnit under Gradle).
 */
public class CoreTests {
    static final long MB = 1L << 20;
    static final String CODE = "123456";
    static final String WRONG = "654321";
    static final SecureRandom RND = new SecureRandom();

    // ---------- tiny helpers ----------
    static void check(boolean ok, String msg) { if (!ok) throw new AssertionError(msg); }

    static final List<File> TMP = Collections.synchronizedList(new ArrayList<File>());

    static File tmp(String p) throws IOException {
        File d = Files.createTempDirectory(p).toFile();
        TMP.add(d);
        return d;
    }

    /** Deletes every temp directory the tests created. */
    public static void cleanup() {
        synchronized (TMP) { for (File d : TMP) deleteAll(d); TMP.clear(); }
    }

    static void deleteAll(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteAll(k);
        f.delete();
    }

    static File makeFile(File dir, String name, long size, long seed) throws IOException {
        File f = new File(dir, name);
        f.getParentFile().mkdirs();
        Random r = new Random(seed);
        byte[] b = new byte[1 << 16];
        try (OutputStream o = new BufferedOutputStream(new FileOutputStream(f), 1 << 16)) {
            long left = size;
            while (left > 0) { r.nextBytes(b); int n = (int) Math.min(b.length, left); o.write(b, 0, n); left -= n; }
        }
        return f;
    }

    static String sha(File f) throws Exception {
        MessageDigest d = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(f)) {
            byte[] b = new byte[1 << 16]; int n;
            while ((n = in.read(b)) > 0) d.update(b, 0, n);
        }
        return Base64.getEncoder().encodeToString(d.digest());
    }

    static final class FileSource implements Source {
        final File f; final String name;
        FileSource(File f, String name) { this.f = f; this.name = name; }
        FileSource(File f) { this(f, f.getName()); }
        public String id() { return Protocol.fileId(name, f.length(), 1L); }
        public String name() { return name; }
        public long size() { return f.length(); }
        public Opened open() throws IOException {
            final FileChannel ch = FileChannel.open(f.toPath(), StandardOpenOption.READ);
            return new Opened() { public FileChannel channel() { return ch; } public void close() throws IOException { ch.close(); } };
        }
    }

    static final class DirFactory implements TargetFactory {
        final File root;
        final File out;
        final AtomicLong free = new AtomicLong(Long.MAX_VALUE / 4);
        final Map<String, String> have = new java.util.concurrent.ConcurrentHashMap<>();
        volatile long slowMs = 0;
        volatile long rate = 0;                       // bytes per second; 0 = unlimited (simulates a slower Wi-Fi / disk link)
        private final Object tb = new Object();
        private long nextNs = 0;
        void throttle(int bytes) {
            if (rate <= 0) return;
            long due;
            synchronized (tb) {
                long now = System.nanoTime(), start = Math.max(now, nextNs);
                nextNs = start + (long) (bytes * 1e9 / rate); due = nextNs;
            }
            long sleep = due - System.nanoTime();
            if (sleep > 0) { try { Thread.sleep(sleep / 1_000_000, (int) (sleep % 1_000_000)); } catch (InterruptedException ignored) {} }
        }
        DirFactory(File root) { this.root = root; new File(root, "part").mkdirs(); this.out = new File(root, "out"); this.out.mkdirs(); }
        public long freeBytes() { return free.get(); }
        public boolean alreadyHave(String id, long size) {
            String p = have.get(id);
            return p != null && new File(p).isFile() && new File(p).length() == size;
        }
        public BitSet peekBits(String id, long size) { return readBits(new File(root, "part/" + id + ".bits")); }
        public Target open(String id, String name, long size) throws IOException { return new DirTarget(this, id, name); }
        File out(String name) { return new File(root, "out/" + name); }
    }

    static BitSet readBits(File f) {
        try { return f.isFile() ? BitSet.valueOf(Files.readAllBytes(f.toPath())) : null; } catch (IOException e) { return null; }
    }

    static final class DirTarget implements Target {
        final DirFactory fac; final String id, name; final File bitsF; final FileChannel ch;
        DirTarget(DirFactory fac, String id, String name) throws IOException {
            this.fac = fac; this.id = id; this.name = name;
            bitsF = new File(fac.root, "part/" + id + ".bits");
            ch = FileChannel.open(new File(fac.root, "part/" + id + ".part").toPath(),
                    StandardOpenOption.CREATE, StandardOpenOption.READ, StandardOpenOption.WRITE);
        }
        public BitSet loadBits() { BitSet b = readBits(bitsF); return b == null ? new BitSet() : b; }
        public synchronized void saveBits(BitSet b) {
            try {                                    // write-then-rename so a reader never sees a half-written file
                File tmpF = new File(bitsF.getPath() + ".tmp");
                Files.write(tmpF.toPath(), b.toByteArray());
                Files.move(tmpF.toPath(), bitsF.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ignored) {}
        }
        public void write(long pos, ByteBuffer src) throws IOException {
            if (fac.slowMs > 0) { try { Thread.sleep(fac.slowMs); } catch (InterruptedException ignored) {} }
            fac.throttle(src.remaining());
            while (src.hasRemaining()) pos += ch.write(src, pos);
        }
        public synchronized void finish() throws IOException {
            ch.close();
            File dst = fac.out(name);
            int i = 1;
            while (dst.exists()) { dst = fac.out(name + " (" + (i++) + ")"); }
            Files.move(new File(fac.root, "part/" + id + ".part").toPath(), dst.toPath());
            bitsF.delete();
            fac.have.put(id, dst.getPath());
        }
        public void close() { try { ch.close(); } catch (IOException ignored) {} }
    }

    static class Rec implements ReceiverEvents {
        final AtomicLong done = new AtomicLong(), total = new AtomicLong();
        final AtomicLong firstBatchDone = new AtomicLong(-1);
        final AtomicInteger started = new AtomicInteger(), finished = new AtomicInteger(), authFails = new AtomicInteger();
        final AtomicInteger blocked = new AtomicInteger(); final AtomicLong need = new AtomicLong();
        volatile java.util.function.LongConsumer hook;
        public void onBatch(long d, long t, int b, long n, String name) {
            firstBatchDone.compareAndSet(-1, d); blocked.set(b); need.set(n);
        }
        public void onProgress(long d, long t) {
            done.set(d); total.set(t);
            java.util.function.LongConsumer h = hook; if (h != null) h.accept(d);
        }
        public void onFileStart(String n) { started.incrementAndGet(); }
        public void onFileDone(String n) { finished.incrementAndGet(); }
        public void onAuthFailed(int n) { authFails.set(n); }
    }

    static Receiver rx(String code, DirFactory f, Rec r) throws IOException {
        Receiver x = new Receiver(code, f, r);
        x.start(0, InetAddress.getLoopbackAddress());
        return x;
    }
    static int portOf(Receiver r) throws Exception {
        java.lang.reflect.Field f = Receiver.class.getDeclaredField("server"); f.setAccessible(true);
        return ((ServerSocket) f.get(r)).getLocalPort();
    }
    static Sender.Result send(int port, String code, List<Source> files) throws IOException {
        return Sender.send("127.0.0.1", port, code, files, (d, t) -> {}, new AtomicBoolean(false));
    }
    interface ThrowingRunnable { void run() throws Exception; }
    static void expectFail(String what, ThrowingRunnable r) throws Exception {
        try { r.run(); } catch (IOException expected) { return; }
        throw new AssertionError("expected failure: " + what);
    }
    static List<Source> one(Source s) { return Collections.singletonList(s); }

    // low-level helpers for attack tests
    static Link login(int port, String code) throws IOException {
        Socket s = new Socket("127.0.0.1", port);
        s.setSoTimeout(5000);
        return Handshake.clientQuery(s, code, RND);
    }
    static Link dataLink(int port, byte[] sid, byte[] key) throws IOException {
        Socket s = new Socket("127.0.0.1", port);
        s.setSoTimeout(5000);
        return Handshake.clientData(s, sid, key);
    }
    static byte[] queryBytes(String id, String name, long size) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        DataOutputStream o = new DataOutputStream(bo);
        o.writeInt(1); o.writeUTF(id); o.writeUTF(name); o.writeLong(size);
        return bo.toByteArray();
    }
    static byte[] headerBytes(String id, int start, int count) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        DataOutputStream o = new DataOutputStream(bo);
        o.writeUTF(id); o.writeInt(start); o.writeInt(count);
        return bo.toByteArray();
    }
    /** True when the peer closed the connection (or reset it) without sending anything more. */
    static boolean closed(Socket s) {
        try { s.setSoTimeout(4000); return s.getInputStream().read() == -1; }
        catch (java.net.SocketTimeoutException e) { return false; }
        catch (IOException e) { return true; }
    }
    static boolean sendAndExpectClose(Link l, byte[] plain) {
        try { l.send(plain, 0, plain.length); } catch (IOException e) { return true; }
        return closed(l.socket);
    }
    /** Announces a file on an authenticated link and returns the receiver's reply. */
    static void announce(Link l, String id, String name, long size) throws IOException {
        byte[] q = queryBytes(id, name, size);
        l.send(q, 0, q.length);
        l.recv(Protocol.MAX_QUERY_PLAIN);
    }
    static int indexOf(byte[] hay, byte[] needle) {
        outer:
        for (int i = 0; i + needle.length <= hay.length; i++) {
            for (int j = 0; j < needle.length; j++) if (hay[i + j] != needle[j]) continue outer;
            return i;
        }
        return -1;
    }

    /** A man-in-the-middle between sender and receiver: records everything, can flip one bit. */
    static final class Proxy implements Closeable {
        final ServerSocket ss; final int target;
        final ByteArrayOutputStream capture = new ByteArrayOutputStream();
        final AtomicLong c2sBytes = new AtomicLong();
        final AtomicBoolean flipped = new AtomicBoolean();
        volatile long flipAfter = -1;
        Proxy(int targetPort) throws IOException {
            this.target = targetPort;
            ss = new ServerSocket(0, 50, InetAddress.getLoopbackAddress());
            Thread t = new Thread(() -> {
                while (!ss.isClosed()) {
                    try {
                        Socket c = ss.accept(); Socket srv = new Socket("127.0.0.1", target);
                        pipe(c, srv, true); pipe(srv, c, false);
                    } catch (IOException e) { break; }
                }
            });
            t.setDaemon(true); t.start();
        }
        int port() { return ss.getLocalPort(); }
        void pipe(final Socket from, final Socket to, final boolean c2s) {
            Thread t = new Thread(() -> {
                byte[] b = new byte[8192];
                try {
                    InputStream in = from.getInputStream(); OutputStream out = to.getOutputStream();
                    int n;
                    while ((n = in.read(b)) >= 0) {
                        if (c2s && flipAfter >= 0) {
                            long before = c2sBytes.getAndAdd(n);
                            if (before + n > flipAfter && !flipped.get()) {
                                int idx = (int) Math.max(0, Math.min(n - 1, flipAfter - before));
                                b[idx] ^= 0x01; flipped.set(true);
                            }
                        }
                        synchronized (capture) { capture.write(b, 0, n); }
                        out.write(b, 0, n); out.flush();
                    }
                } catch (IOException ignored) {
                } finally { try { from.close(); } catch (IOException ignored) {} try { to.close(); } catch (IOException ignored) {} }
            });
            t.setDaemon(true); t.start();
        }
        byte[] captured() { synchronized (capture) { return capture.toByteArray(); } }
        public void close() { try { ss.close(); } catch (IOException ignored) {} }
    }

    // ================= basic behaviour =================
    public static void testNames() {
        check(Names.sanitize("../../etc/passwd").equals("passwd"), "unix traversal");
        check(Names.sanitize("..\\..\\win\\system.ini").equals("system.ini"), "windows traversal");
        check(Names.sanitize("..").equals("file"), "dotdot");
        check(Names.sanitize(".").equals("file"), "dot");
        check(Names.sanitize("").equals("file"), "empty");
        check(Names.sanitize(null).equals("file"), "null");
        check(Names.sanitize("a\u0000b\nc.txt").equals("abc.txt"), "control chars");
        check(Names.sanitize("a:b*c?.txt").equals("a_b_c_.txt"), "bad chars");
        check(Names.sanitize("Holiday photo (1).jpg").equals("Holiday photo (1).jpg"), "normal name kept");
        check(Names.sanitize("backup.tar.gz").equals("backup.tar.gz"), "tar.gz kept");
        check(Names.sanitize("archive.ZIP").equals("archive.ZIP"), "zip kept");
        check(Names.sanitize("\u0926\u0938\u094d\u0924\u093e\u0935\u0947\u091c\u093c.zip").endsWith(".zip"), "unicode name kept");
        check(Names.sanitize("video.mp4 ").equals("video.mp4"), "trailing space");
        StringBuilder sb = new StringBuilder(); for (int i = 0; i < 400; i++) sb.append('x');
        String longName = Names.sanitize(sb + ".mp4");
        check(longName.length() <= Protocol.MAX_NAME && longName.endsWith(".mp4"), "long name keeps extension");
    }

    public static void testKeys() throws Exception {
        String c = Keys.newCode();
        check(Keys.isValid(c) && c.length() == 6 && c.matches("[0-9]{6}"), "new code is six digits: " + c);
        check(Keys.normalize("12a-34 56 78").equals("123456"), "normalize keeps six digits");
        check(Keys.normalize("abc").isEmpty(), "letters removed");
        check(!Keys.isValid("12345") && !Keys.isValid("1234567") && !Keys.isValid("12345a") && !Keys.isValid(null), "invalid rejected");
        check(Keys.pretty("123456").equals("123 456"), "pretty");
        Keys a = Keys.derive("123456", 1000), b = Keys.derive("123456", 1000), d = Keys.derive("123457", 1000);
        check(a.wifiName.equals(b.wifiName) && a.wifiPass.equals(b.wifiPass), "deterministic");
        check(!a.wifiPass.equals(d.wifiPass) && !a.wifiName.equals(d.wifiName), "different codes differ");
        check(a.wifiName.startsWith("DIRECT-SS-") && a.wifiName.length() <= 32, "ssid format");
        check(a.wifiPass.length() >= 8 && a.wifiPass.length() <= 63 && a.wifiPass.matches("[0-9a-f]+"), "wifi password format");
    }

    public static void testCodeDistribution() {
        int[] digits = new int[10]; int N = 60000;
        for (int i = 0; i < N; i++) { String c = Keys.newCode(); check(Keys.isValid(c), "valid"); for (char ch : c.toCharArray()) digits[ch - '0']++; }
        double expected = N * 6 / 10.0, chi = 0;
        for (int f : digits) chi += (f - expected) * (f - expected) / expected;
        check(chi < 40, "digits are uniformly distributed (chi-square " + String.format("%.1f", chi) + ", 9 dof)");
        Set<String> firsts = new HashSet<>();
        for (int i = 0; i < 3000; i++) firsts.add(Keys.newCode());
        check(firsts.size() > 2900, "codes vary widely (" + firsts.size() + " distinct of 3000)");
    }

    public static void testSrp() throws Exception {
        byte[] salt = Srp.newSalt(RND);
        BigInteger v = Srp.verifier("123456", salt);
        Srp.Client c = new Srp.Client("123456", RND);
        Srp.Server s = new Srp.Server(v, RND);
        byte[] k1 = c.sessionKey(salt, s.publicB()), k2 = s.sessionKey(c.publicA());
        check(Arrays.equals(k1, k2) && k1.length == 32, "same code gives the same session key");
        Srp.Client bad = new Srp.Client("123457", RND);
        Srp.Server s2 = new Srp.Server(v, RND);
        check(!Arrays.equals(bad.sessionKey(salt, s2.publicB()), s2.sessionKey(bad.publicA())), "a wrong code gives a different key");
        Srp.Client c3 = new Srp.Client("123456", RND); Srp.Server s3 = new Srp.Server(v, RND);
        check(!Arrays.equals(c3.sessionKey(salt, s3.publicB()), k1), "every login gets a fresh key");
        BigInteger N = Srp.N;
        BigInteger[] evil = { BigInteger.ZERO, BigInteger.ONE, N.subtract(BigInteger.ONE), N, N.add(BigInteger.ONE) };
        for (BigInteger e : evil) {
            byte[] raw = Srp.pad(e.mod(BigInteger.ONE.shiftLeft(2048)));
            final byte[] val = raw;
            boolean threw = false;
            try { new Srp.Server(v, RND).sessionKey(val); } catch (java.security.GeneralSecurityException ex) { threw = true; }
            check(threw, "server rejects degenerate client value " + e.bitLength());
            threw = false;
            try { new Srp.Client("123456", RND).sessionKey(salt, val); } catch (java.security.GeneralSecurityException ex) { threw = true; }
            check(threw, "client rejects degenerate server value " + e.bitLength());
        }
    }

    public static void testFrameCipher() throws Exception {
        byte[] key = new byte[32]; RND.nextBytes(key);
        Crypto.FrameCipher enc = new Crypto.FrameCipher(key, true), dec = new Crypto.FrameCipher(key, false);
        byte[] msg = new byte[1000]; RND.nextBytes(msg);
        byte[] ct1 = new byte[1016], ct2 = new byte[1016], out = new byte[1016];
        int n1 = enc.seal(msg, 0, 1000, ct1), n2 = enc.seal(msg, 0, 1000, ct2);
        check(!Arrays.equals(Arrays.copyOf(ct1, n1), Arrays.copyOf(ct2, n2)), "same plaintext gives different ciphertext per frame");
        check(indexOf(ct1, Arrays.copyOf(msg, 32)) < 0, "ciphertext does not contain the plaintext");
        check(dec.open(ct1, n1, out) == 1000 && Arrays.equals(Arrays.copyOf(out, 1000), msg), "decrypts");
        // reordered / repeated / altered frames must fail
        Crypto.FrameCipher dec2 = new Crypto.FrameCipher(key, false);
        boolean threw = false;
        try { dec2.open(ct2, n2, out); } catch (java.security.GeneralSecurityException e) { threw = true; }
        check(threw, "out-of-order frame rejected");
        Crypto.FrameCipher dec3 = new Crypto.FrameCipher(key, false);
        ct1[500] ^= 1; threw = false;
        try { dec3.open(ct1, n1, out); } catch (java.security.GeneralSecurityException e) { threw = true; }
        check(threw, "altered frame rejected");
        Crypto.FrameCipher dec4 = new Crypto.FrameCipher(key, false);
        enc = new Crypto.FrameCipher(key, true);
        enc.seal(msg, 0, 10, ct1);
        threw = false;
        try { dec4.open(ct1, 26, out); dec4.open(ct1, 26, out); } catch (java.security.GeneralSecurityException e) { threw = true; }
        check(threw, "repeated frame rejected");
    }

    // ================= transfers =================
    public static void testTransfer() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try {
            List<Source> files = new ArrayList<>();
            files.add(new FileSource(makeFile(src, "empty.bin", 0, 1)));
            files.add(new FileSource(makeFile(src, "one.bin", 1, 2)));
            files.add(new FileSource(makeFile(src, "Holiday photo (final).jpg", 1_000_003, 3)));
            files.add(new FileSource(makeFile(src, "clip.mp4", 5 * MB + 17, 4)));
            files.add(new FileSource(makeFile(src, "big movie.mkv", 45 * MB + 5, 5)));   // > 32 MB: parallel streams
            Sender.Result res = send(portOf(r), CODE, files);
            check(res.complete && res.blockedIds.isEmpty(), "complete");
            for (Source s : files) {
                File out = fac.out(s.name());
                check(out.isFile(), "received " + s.name());
                check(out.length() == s.size(), "size " + s.name());
                check(sha(out).equals(sha(((FileSource) s).f)), "hash " + s.name());
            }
            check(rec.done.get() == rec.total.get(), "progress reaches 100%");
        } finally { r.stop(); }
    }

    /** Every kind of file works: archives, installers, disk images, no extension, hidden files, odd sizes. */
    public static void testAllFileTypes() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try {
            String[] names = {"archive.zip", "backup.tar.gz", "logs.gz", "setup.exe", "disk.iso", "app.apk", "data.7z",
                    "old.rar", "database.sqlite", "noextension", ".hidden", "UPPER.ZIP", "weird name (1) [final].rar",
                    "notes.txt", "sheet.xlsx", "book.pdf", "song.flac", "model.bin", "bundle.aab", "firmware.img"};
            long[] sizes = {0, 1, Protocol.CHUNK - 1, Protocol.CHUNK, Protocol.CHUNK + 1, 2L * Protocol.CHUNK + 7, 12345, 999_999};
            List<Source> files = new ArrayList<>();
            for (int i = 0; i < names.length; i++) files.add(new FileSource(makeFile(src, names[i], sizes[i % sizes.length], 900 + i)));
            Sender.Result res = send(portOf(r), CODE, files);
            check(res.complete, "all file types sent");
            for (Source s : files) {
                File out = fac.out(s.name());
                check(out.isFile() && out.length() == s.size(), "stored with its real name: " + s.name());
                check(sha(out).equals(sha(((FileSource) s).f)), "identical: " + s.name());
            }
        } finally { r.stop(); }
    }

    public static void testResume() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        FileSource fs = new FileSource(makeFile(src, "huge.bin", 120 * MB, 9));
        fac.slowMs = 10;
        final Rec rec1 = new Rec();
        final Receiver r1 = rx(CODE, fac, rec1);
        final AtomicBoolean stopped = new AtomicBoolean(false);
        rec1.hook = d -> { if (d >= 50 * MB && !stopped.getAndSet(true)) new Thread(r1::stop).start(); };
        int p1 = portOf(r1);
        expectFail("interrupted transfer", () -> send(p1, CODE, one(fs)));
        r1.stop();
        check(stopped.get(), "receiver was stopped mid-transfer");
        BitSet saved = fac.peekBits(fs.id(), fs.size());
        check(saved != null && saved.cardinality() > 0, "progress was saved");
        check(saved.cardinality() < Protocol.chunksOf(fs.size()), "transfer was really partial");
        check(!fac.out("huge.bin").exists(), "no half file is published");

        fac.slowMs = 0;
        final Rec rec2 = new Rec();
        Receiver r2 = rx(CODE, fac, rec2);          // new session, same code: resumes
        try {
            final long[] first = {-1};
            Sender.Result res = Sender.send("127.0.0.1", portOf(r2), CODE, one(fs),
                    (d, t) -> { if (first[0] < 0) first[0] = d; }, new AtomicBoolean(false));
            check(res.complete, "resume completes");
            check(first[0] > 0, "resume started from saved progress, not from zero (" + first[0] + ")");
            check(rec2.firstBatchDone.get() == first[0], "receiver and sender agree on resume point");
            check(sha(fac.out("huge.bin")).equals(sha(fs.f)), "file identical after resume");
        } finally { r2.stop(); }
    }

    public static void testInsufficientStorage() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try {
            FileSource a = new FileSource(makeFile(src, "first.zip", 40 * MB, 1));
            FileSource b = new FileSource(makeFile(src, "second.zip", 40 * MB, 2));
            fac.free.set(Protocol.RESERVE_BYTES + 50 * MB);
            List<Source> both = new ArrayList<>(); both.add(a); both.add(b);
            Sender.Result res = send(portOf(r), CODE, both);
            check(!res.complete, "not complete: second file does not fit");
            check(res.blockedIds.size() == 1 && res.blockedIds.get(0).equals(b.id()), "second file reported as blocked");
            check(res.needMore == 30 * MB, "shortfall is exact: " + res.needMore);
            check(rec.blocked.get() == 1 && rec.need.get() == 30 * MB, "receiver reports the same shortfall");
            check(fac.out("first.zip").isFile() && sha(fac.out("first.zip")).equals(sha(a.f)), "first file received intact");
            check(!fac.out("second.zip").exists(), "second file not started");

            fac.free.set(Long.MAX_VALUE / 4);            // user freed space on the receiver
            Sender.Result again = send(portOf(r), CODE, both);
            check(again.complete && again.blockedIds.isEmpty(), "completes after space was freed");
            check(again.haveCount == 1, "first file was not sent twice");
            check(sha(fac.out("second.zip")).equals(sha(b.f)), "second file intact");
            check(!fac.out("first.zip (1)").exists(), "no duplicate copy of the first file");
        } finally { r.stop(); }
    }

    public static void testManyFilesNeverOverCommitSpace() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try {
            List<Source> files = new ArrayList<>();
            for (int i = 0; i < 200; i++) files.add(new FileSource(makeFile(src, "f" + i + ".bin", 262144, 100 + i)));
            fac.free.set(Protocol.RESERVE_BYTES + 80L * 262144);      // room for exactly 80 files
            Sender.Result res = send(portOf(r), CODE, files);
            int stored = fac.out.list().length;
            check(!res.complete && res.blockedIds.size() == 120, "120 files blocked, got " + res.blockedIds.size());
            check(stored == 80, "exactly 80 files stored, got " + stored);
            check(res.needMore == 262144, "shortfall reported for the next file: " + res.needMore);
        } finally { r.stop(); }
    }

    public static void testAlreadyHave() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try {
            FileSource a = new FileSource(makeFile(src, "a.bin", 3 * MB, 1));
            FileSource b = new FileSource(makeFile(src, "b.bin", 3 * MB, 2));
            List<Source> both = new ArrayList<>(); both.add(a); both.add(b);
            check(send(portOf(r), CODE, both).complete, "first send");
            int startedBefore = rec.started.get();
            Sender.Result again = send(portOf(r), CODE, both);
            check(again.complete && again.haveCount == 2, "second send finds both files already there");
            check(rec.started.get() == startedBefore, "nothing sent again");
            check(fac.out("a.bin").delete(), "receiver deletes a.bin to free space");
            Sender.Result third = send(portOf(r), CODE, both);
            check(third.complete && third.haveCount == 1, "only the deleted file is sent again");
            check(sha(fac.out("a.bin")).equals(sha(a.f)), "re-sent file intact");
        } finally { r.stop(); }
    }

    public static void testConcurrentSenders() throws Exception {
        final DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try {
            final int port = portOf(r);
            final List<FileSource> all = Collections.synchronizedList(new ArrayList<FileSource>());
            List<Thread> th = new ArrayList<>(); final List<Throwable> errs = Collections.synchronizedList(new ArrayList<Throwable>());
            for (int t = 0; t < 4; t++) {
                final File src = tmp("src" + t); final int id = t;
                Thread x = new Thread(() -> {
                    try {
                        List<Source> files = new ArrayList<>();
                        for (int k = 0; k < 3; k++) { FileSource fs = new FileSource(makeFile(src, "s" + id + "-" + k + ".bin", (k + 1) * 3 * MB + id, id * 10 + k)); files.add(fs); all.add(fs); }
                        check(send(port, CODE, files).complete, "sender " + id + " complete");
                    } catch (Throwable e) { errs.add(e); }
                });
                th.add(x); x.start();
            }
            for (Thread x : th) x.join();
            check(errs.isEmpty(), "no errors: " + errs);
            for (FileSource fs : all) check(sha(fac.out(fs.name())).equals(sha(fs.f)), "intact " + fs.name());
        } finally { r.stop(); }
    }

    public static void testCancel() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); fac.slowMs = 10;
        Receiver r = rx(CODE, fac, rec);
        try {
            FileSource fs = new FileSource(makeFile(src, "c.bin", 60 * MB, 1));
            final AtomicBoolean cancel = new AtomicBoolean(false);
            long t0 = System.nanoTime();
            try {
                Sender.send("127.0.0.1", portOf(r), CODE, one(fs), (d, t) -> { if (d > 10 * MB) cancel.set(true); }, cancel);
                throw new AssertionError("expected cancel");
            } catch (IOException expected) { /* ok */ }
            check((System.nanoTime() - t0) / 1e9 < 15, "cancel stops promptly");
            check(!fac.out("c.bin").exists(), "cancelled file not published");
        } finally { r.stop(); }
    }

    // ================= security: login =================
    public static void testWrongCodeAndLockout() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try {
            FileSource fs = new FileSource(makeFile(src, "secret.txt", 100_000, 1));
            expectFail("wrong code", () -> send(portOf(r), WRONG, one(fs)));
            check(rec.authFails.get() == 1, "failed attempt counted");
            check(rec.started.get() == 0 && !fac.out("secret.txt").exists(), "nothing stored for a wrong code");
            check(send(portOf(r), CODE, one(fs)).complete, "right code still works after one mistake");
            for (int i = 1; i < Protocol.MAX_AUTH_FAILURES; i++) {
                try { send(portOf(r), WRONG, one(fs)); } catch (IOException ignored) {}
            }
            check(r.authFailures() >= Protocol.MAX_AUTH_FAILURES, "failures counted");
            expectFail("locked out after too many wrong attempts", () -> send(portOf(r), CODE, one(fs)));
        } finally { r.stop(); }
    }

    public static void testReplay() throws Exception {
        DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try {
            int port = portOf(r);
            byte[] A, M1;
            try (Socket s1 = new Socket("127.0.0.1", port)) {          // a legitimate login that an attacker records
                s1.setSoTimeout(5000);
                DataInputStream in = new DataInputStream(s1.getInputStream());
                DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s1.getOutputStream()));
                byte[] n1 = new byte[16]; in.readFully(n1);
                out.writeByte(Protocol.T_QUERY);
                Srp.Client c = new Srp.Client(CODE, RND);
                A = c.publicA(); out.writeInt(256); out.write(A); out.flush();
                byte[] salt = new byte[16], B = new byte[256], sid = new byte[8];
                in.readFully(salt); in.readInt(); in.readFully(B); in.readFully(sid);
                byte[] K = c.sessionKey(salt, B);
                M1 = Crypto.hmac(K, "M1", n1, A, B, salt, sid);
                out.write(M1); out.flush();
                byte[] m2 = new byte[32]; in.readFully(m2);
            }
            check(rec.authFails.get() == 0, "legitimate login accepted");
            try (Socket s2 = new Socket("127.0.0.1", port)) {          // replay the recorded messages
                s2.setSoTimeout(5000);
                DataInputStream in = new DataInputStream(s2.getInputStream());
                DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s2.getOutputStream()));
                in.readFully(new byte[16]);
                out.writeByte(Protocol.T_QUERY); out.writeInt(256); out.write(A); out.flush();
                in.readFully(new byte[16]); in.readInt(); in.readFully(new byte[256]); in.readFully(new byte[8]);
                out.write(M1); out.flush();
                check(closed(s2), "replayed login is rejected");
            }
            check(rec.authFails.get() == 1, "replay counted as a failed attempt");

            // a data-connection proof cannot be reused on another connection either
            Link l = login(port, CODE);
            byte[] proofA;
            try (Socket sa = new Socket("127.0.0.1", port)) {
                sa.setSoTimeout(5000);
                byte[] na = new byte[16]; new DataInputStream(sa.getInputStream()).readFully(na);
                proofA = Crypto.hmac(l.sessionKey, "DATA", na, l.sessionId);
            }
            try (Socket sb = new Socket("127.0.0.1", port)) {
                sb.setSoTimeout(5000);
                new DataInputStream(sb.getInputStream()).readFully(new byte[16]);
                OutputStream o = sb.getOutputStream();
                o.write(Protocol.T_DATA); o.write(l.sessionId); o.write(proofA); o.flush();
                check(closed(sb), "replayed data proof is rejected");
            }
            l.close();
            // data connection for a session id that does not exist
            try (Socket sc = new Socket("127.0.0.1", port)) {
                sc.setSoTimeout(5000);
                new DataInputStream(sc.getInputStream()).readFully(new byte[16]);
                OutputStream o = sc.getOutputStream();
                byte[] junk = new byte[8 + 32]; RND.nextBytes(junk);
                o.write(Protocol.T_DATA); o.write(junk); o.flush();
                check(closed(sc), "unknown session rejected");
            }
            check(rec.started.get() == 0, "nothing stored");
        } finally { r.stop(); }
    }

    public static void testIdleAndConnectionFlood() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try {
            int port = portOf(r);
            long t0 = System.nanoTime();
            try (Socket s = new Socket("127.0.0.1", port)) {              // never answers
                s.setSoTimeout(9000);
                InputStream in = s.getInputStream();
                int got = 0, x;
                while ((x = in.read()) >= 0) got++;
                double sec = (System.nanoTime() - t0) / 1e9;
                check(got == 16, "only the 16-byte challenge is sent (" + got + ")");
                check(sec > 3 && sec < 8, "idle peer dropped after the pre-auth timeout: " + sec + "s");
            }
            List<Socket> socks = new ArrayList<>();
            int extra = 10, closedAtOnce = 0;
            for (int i = 0; i < Protocol.MAX_CONNECTIONS + extra; i++) socks.add(new Socket("127.0.0.1", port));
            Thread.sleep(500);
            for (Socket s : socks) {
                s.setSoTimeout(700);
                try { if (s.getInputStream().read() == -1) closedAtOnce++; } catch (java.net.SocketTimeoutException e) { /* holds a slot */ }
                catch (IOException e) { closedAtOnce++; }
            }
            check(closedAtOnce >= extra - 1, "connections above the limit are refused (" + closedAtOnce + ")");
            for (Socket s : socks) s.close();
            Thread.sleep(800);
            FileSource fs = new FileSource(makeFile(src, "after-flood.bin", 200_000, 1));
            check(send(port, CODE, one(fs)).complete, "serves transfers after the flood");
            check(sha(fac.out("after-flood.bin")).equals(sha(fs.f)), "file intact after flood");
        } finally { r.stop(); }
    }

    // ================= security: encryption & integrity =================
    public static void testEavesdropperSeesNothing() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try (Proxy p = new Proxy(portOf(r))) {
            File f = new File(src, "TopSecretPlans.zip");
            byte[] marker = "SUPERSHARE-SECRET-MARKER-0123456789-".getBytes(StandardCharsets.UTF_8);
            try (OutputStream o = new FileOutputStream(f)) { for (int i = 0; i < 60000; i++) o.write(marker); }   // ~2 MB
            FileSource fs = new FileSource(f);
            check(send(p.port(), CODE, one(fs)).complete, "transfer through the observer works");
            check(sha(fac.out("TopSecretPlans.zip")).equals(sha(f)), "file intact");
            byte[] seen = p.captured();
            check(seen.length > 2_000_000, "observer saw the whole conversation (" + seen.length + " bytes)");
            check(indexOf(seen, Arrays.copyOf(marker, 16)) < 0, "file content never appears on the wire");
            check(indexOf(seen, "TopSecretPlans".getBytes(StandardCharsets.UTF_8)) < 0, "file name never appears on the wire");
            check(indexOf(seen, CODE.getBytes(StandardCharsets.UTF_8)) < 0, "the code never appears on the wire");
        }
        finally { r.stop(); }
    }

    public static void testTamperedTraffic() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try (Proxy p = new Proxy(portOf(r))) {
            FileSource fs = new FileSource(makeFile(src, "payload.zip", 20 * MB, 5));
            p.flipAfter = 3 * MB;                                         // an attacker flips one bit in transit
            expectFail("tampered data must be detected", () -> send(p.port(), CODE, one(fs)));
            check(p.flipped.get(), "the bit was flipped");
            check(!fac.out("payload.zip").exists(), "a damaged file is never published");
            p.flipAfter = -1;
            check(send(portOf(r), CODE, one(fs)).complete, "clean retry completes");
            check(sha(fac.out("payload.zip")).equals(sha(fs.f)), "final file is bit-for-bit identical");
        } finally { r.stop(); }
    }

    // ================= security: hostile / malformed input =================
    public static void testAuthenticatedHostileMessages() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try {
            int port = portOf(r);
            // hostile announcements from a logged-in peer: each is dropped, never answered
            Link l;
            l = login(port, CODE); check(sendAndExpectClose(l, new byte[]{0x7f, (byte) 0xff, (byte) 0xff, (byte) 0xff}), "huge file count rejected"); l.close();
            l = login(port, CODE); check(sendAndExpectClose(l, queryBytes("abc", "x", -5)), "negative size rejected"); l.close();
            l = login(port, CODE); check(sendAndExpectClose(l, queryBytes("../x", "x", 5)), "bad id rejected"); l.close();
            l = login(port, CODE); check(sendAndExpectClose(l, queryBytes("abc", "x", Long.MAX_VALUE)), "absurd size rejected"); l.close();
            l = login(port, CODE); check(sendAndExpectClose(l, new byte[0]), "empty message rejected"); l.close();
            // data requests that make no sense
            l = login(port, CODE);
            announce(l, "okid", "ok.bin", 1000);
            Link d = dataLink(port, l.sessionId, l.sessionKey);
            check(sendAndExpectClose(d, headerBytes("unknownfile", 0, 1)), "data for unknown file rejected"); d.close();
            d = dataLink(port, l.sessionId, l.sessionKey);
            check(sendAndExpectClose(d, headerBytes("okid", 99, 1)), "out-of-range chunk rejected"); d.close();
            d = dataLink(port, l.sessionId, l.sessionKey);
            check(sendAndExpectClose(d, headerBytes("okid", 0, Integer.MAX_VALUE)), "absurd chunk count rejected"); d.close();
            d = dataLink(port, l.sessionId, l.sessionKey);
            byte[] hdr = headerBytes("okid", 0, 1); d.send(hdr, 0, hdr.length);
            check(sendAndExpectClose(d, new byte[5000]), "more data than announced rejected"); d.close();
            d = dataLink(port, l.sessionId, l.sessionKey);
            d.send(hdr, 0, hdr.length);
            check(sendAndExpectClose(d, new byte[0]), "empty data block rejected"); d.close();
            check(!fac.out("ok.bin").exists(), "nothing was published");
            l.close();
            FileSource fs = new FileSource(makeFile(src, "ok2.bin", 100_000, 3));
            check(send(port, CODE, one(fs)).complete, "receiver still serves valid transfers");
            check(sha(fac.out("ok2.bin")).equals(sha(fs.f)), "valid file intact");
        } finally { r.stop(); }
    }

    public static void testMemoryExhaustionGuards() throws Exception {
        DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try {
            int port = portOf(r);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            DataOutputStream o = new DataOutputStream(bo);
            o.writeInt(2000);
            for (int i = 0; i < 2000; i++) { o.writeUTF("f" + i); o.writeUTF("x"); o.writeLong(1L << 42); }   // would need ~250 MB of bitmaps
            Link l = login(port, CODE);
            long t0 = System.nanoTime();
            check(sendAndExpectClose(l, bo.toByteArray()), "absurd announcement rejected");
            check((System.nanoTime() - t0) / 1e9 < 3, "rejected quickly");
            l.close();
            l = login(port, CODE);
            check(sendAndExpectClose(l, new byte[]{0, 0, 7, (byte) 0xd1}), "more than the maximum file count rejected");   // 2001
            l.close();
            check(rec.started.get() == 0 && fac.root.list().length == 2, "nothing created");
        } finally { r.stop(); }
    }

    public static void testFuzzReceiver() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try {
            int port = portOf(r);
            Random rnd = new Random(4242);
            // 1) garbage before login
            for (int i = 0; i < 250; i++) {
                try (Socket s = new Socket("127.0.0.1", port)) {
                    s.setSoTimeout(3000);
                    byte[] payload = new byte[rnd.nextInt(400)];
                    rnd.nextBytes(payload);
                    if (payload.length > 0 && i % 3 == 0) payload[0] = (byte) (1 + rnd.nextInt(2));   // plausible type byte
                    s.getOutputStream().write(payload); s.getOutputStream().flush();
                    s.shutdownOutput();
                    try { while (s.getInputStream().read() >= 0) { } } catch (IOException ignored) {}
                }
            }
            // 2) garbage and bit-flips after a valid login
            for (int i = 0; i < 120; i++) {
                Link l = login(port, CODE);
                try {
                    if (i % 2 == 0) {                                        // random plaintext message
                        byte[] m = new byte[rnd.nextInt(300)]; rnd.nextBytes(m);
                        l.send(m, 0, m.length);
                    } else {                                                 // random bytes posing as an encrypted frame
                        byte[] m = new byte[16 + rnd.nextInt(300)]; rnd.nextBytes(m);
                        l.out.writeInt(m.length); l.out.write(m); l.out.flush();
                    }
                    l.socket.shutdownOutput();
                    l.socket.setSoTimeout(3000);
                    try { while (l.socket.getInputStream().read() >= 0) { } } catch (IOException ignored) {}
                } finally { l.close(); }
            }
            check(rec.started.get() == 0, "no file was started by garbage");
            String[] top = fac.root.list(); Arrays.sort(top);
            check(Arrays.equals(top, new String[]{"out", "part"}), "no stray files: " + Arrays.toString(top));
            check(r.authFailures() < Protocol.MAX_AUTH_FAILURES, "garbage did not trigger the lock-out (" + r.authFailures() + ")");
            FileSource fs = new FileSource(makeFile(src, "alive.bin", 300_000, 8));
            check(send(port, CODE, one(fs)).complete, "receiver survives the fuzzing");
            check(sha(fac.out("alive.bin")).equals(sha(fs.f)), "valid transfer intact after fuzzing");
        } finally { r.stop(); }
    }

    public static void testNameFuzz() {
        Random rnd = new Random(777);
        String specials = "/\\:*?\"<>|.. \u0000\n\t\u007f\u202e\u2028~$%";
        for (int i = 0; i < 40000; i++) {
            StringBuilder sb = new StringBuilder();
            int len = rnd.nextInt(i % 50 == 0 ? 600 : 40);
            for (int k = 0; k < len; k++) {
                int pick = rnd.nextInt(4);
                if (pick == 0) sb.append(specials.charAt(rnd.nextInt(specials.length())));
                else if (pick == 1) sb.appendCodePoint(0x20 + rnd.nextInt(0x2FFF));
                else sb.append((char) ('a' + rnd.nextInt(26)));
            }
            String out = Names.sanitize(sb.toString());
            check(out != null && !out.isEmpty() && out.length() <= Protocol.MAX_NAME, "length of '" + out + "'");
            check(out.indexOf('/') < 0 && out.indexOf('\\') < 0, "no separators in '" + out + "'");
            check(!out.equals(".") && !out.equals(".."), "not a dot name");
            check(!out.endsWith(".") && !out.endsWith(" "), "no trailing dot/space in '" + out + "'");
            for (int k = 0; k < out.length(); k++) { char c = out.charAt(k); check(c >= 0x20 && c != 0x7f, "no control char"); }
            check(Names.sanitize(out).equals(out), "idempotent: " + out);
        }
    }

    public static void testPathTraversalName() throws Exception {
        File src = tmp("src"); File rxRoot = tmp("rx"); DirFactory fac = new DirFactory(rxRoot);
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try {
            File real = makeFile(src, "payload.bin", 2000, 1);
            FileSource evil = new FileSource(real, "../../evil.txt");
            check(send(portOf(r), CODE, one(evil)).complete, "transfer works");
            check(fac.out("evil.txt").isFile(), "stored under the plain name");
            check(!new File(rxRoot.getParentFile(), "evil.txt").exists(), "nothing written outside the folder");
            check(!new File(rxRoot.getParentFile().getParentFile(), "evil.txt").exists(), "nothing written two levels up");
        } finally { r.stop(); }
    }

    // ================= security: hostile receiver =================
    static void fakeReceiver(final ServerSocket fake, final int mode, final Thread[] holder) {
        Thread th = new Thread(() -> {
            try (Socket s = fake.accept()) {
                s.setSoTimeout(5000);
                DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream()));
                DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
                byte[] nonce = new byte[16]; RND.nextBytes(nonce);
                out.write(nonce); out.flush();
                in.readByte();
                byte[] salt = Srp.newSalt(RND);
                BigInteger v = Srp.verifier(CODE, salt);
                if (mode == 1) {                                             // invalid server value (zero)
                    in.readInt(); in.readFully(new byte[256]);
                    out.write(salt); out.writeInt(256); out.write(new byte[256]); out.write(new byte[8]); out.flush();
                    Thread.sleep(500);
                } else if (mode == 2) {                                      // valid exchange but wrong proof
                    in.readInt(); byte[] a = new byte[256]; in.readFully(a);
                    Srp.Server sv = new Srp.Server(v, RND); sv.sessionKey(a);
                    out.write(salt); out.writeInt(256); out.write(sv.publicB()); out.write(new byte[8]); out.flush();
                    in.readFully(new byte[32]);
                    byte[] bogus = new byte[32]; RND.nextBytes(bogus); out.write(bogus); out.flush();
                    Thread.sleep(500);
                } else {                                                     // honest login, then a hostile reply
                    Link l = Handshake.serverQuery(s, in, out, nonce, salt, v, RND);
                    l.recv(Protocol.MAX_QUERY_PLAIN);
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    DataOutputStream o = new DataOutputStream(bo);
                    o.writeLong(0); o.writeInt(1); o.writeByte(0); o.writeLong(0); o.writeInt(1 << 30);
                    l.send(bo.toByteArray(), 0, bo.size());
                    Thread.sleep(500);
                }
            } catch (Exception ignored) {}
        });
        holder[0] = th;
        th.start();
    }

    public static void testMaliciousReceiver() throws Exception {
        File src = tmp("src");
        FileSource fs = new FileSource(makeFile(src, "x.bin", 1000, 1));
        for (int mode = 1; mode <= 3; mode++) {
            final ServerSocket fake = new ServerSocket(0, 5, InetAddress.getLoopbackAddress());
            Thread[] holder = new Thread[1];
            fakeReceiver(fake, mode, holder);
            long t0 = System.nanoTime();
            expectFail("hostile receiver mode " + mode, () -> Sender.send("127.0.0.1", fake.getLocalPort(), CODE, one(fs), (d, t) -> {}, new AtomicBoolean(false)));
            check((System.nanoTime() - t0) / 1e9 < 6, "refused quickly (mode " + mode + ")");
            holder[0].join(); fake.close();
        }
    }

    /** Names that real phones have: hidden files, many dots, spaces, symbols, very long, no extension. */
    public static void testOddFileNames() throws Exception {
        File src = tmp("src"); DirFactory fac = new DirFactory(tmp("rx"));
        Rec rec = new Rec(); Receiver r = rx(CODE, fac, rec);
        try {
            StringBuilder lng = new StringBuilder(); for (int i = 0; i < 150; i++) lng.append('n');
            String[] names = {".bashrc", ".gitignore", "a b  c.txt", "file.with.many.dots.tar.gz", "UPPER", "no_ext", "semi;colon&amp.txt",
                    "100%.bin", "#hash.txt", "(1) copy [2] {3}.doc", "it's mine.pdf", "tilde~.bak", "plus+equals=.dat", "@at.cfg", lng + ".dat",
                    "IMG_0001.HEIC", "report_final_v2.docx", "backup-2026-11-10.7z", "movie.mkv", "sound.flac", "installer.msi", "data.json", "x.y"};
            List<Source> files = new ArrayList<>();
            for (int i = 0; i < names.length; i++) files.add(new FileSource(makeFile(src, names[i], 1000 + i * 977L, 700 + i)));
            check(send(portOf(r), CODE, files).complete, "all sent");
            for (Source s : files) {
                File out = fac.out(s.name());
                check(out.isFile() && out.length() == s.size(), "stored with its exact name: " + s.name());
                check(sha(out).equals(sha(((FileSource) s).f)), "identical: " + s.name());
            }
            check(fac.out.list().length == names.length, "no extra or renamed files");
        } finally { r.stop(); }
    }

    // ================= group share =================
    static void rawRegister(String srcIp, int port, int magic, String name, int announcedPort) {
        try (Socket s = new Socket()) {
            s.bind(new java.net.InetSocketAddress(srcIp, 0));
            s.connect(new java.net.InetSocketAddress("127.0.0.1", port), 3000);
            s.setSoTimeout(3000);
            DataOutputStream o = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
            o.writeInt(magic); o.writeByte(1); o.writeUTF(name); o.writeInt(announcedPort); o.flush();
            s.getInputStream().read();
        } catch (IOException ignored) {}
    }

    public static void testRegistry() throws Exception {
        Registry reg = new Registry();
        int port = reg.start(0, InetAddress.getLoopbackAddress());
        try {
            Registry.register("127.0.0.1", port, "Ravi's phone", 8988);
            check(reg.devices().size() == 1 && reg.devices().get(0).name.equals("Ravi's phone") && reg.devices().get(0).port == 8988, "one device listed");
            Registry.register("127.0.0.1", port, "Ravi's phone (renamed)", 8988);
            check(reg.devices().size() == 1, "same phone announcing again is not listed twice");
            // names are cleaned
            rawRegister("127.0.0.2", port, Registry.MAGIC, "<b>Evil\u0000\n" + "x".repeat(500), 8988);
            Registry.Device d2 = null;
            for (Registry.Device d : reg.devices()) if (d.ip.equals("127.0.0.2")) d2 = d;
            check(d2 != null && d2.name.length() <= 40 && !d2.name.contains("<") && d2.name.indexOf('\u0000') < 0 && d2.name.indexOf('\n') < 0, "hostile name cleaned: " + (d2 == null ? null : d2.name));
            // hostile registrations are ignored
            int before = reg.devices().size();
            rawRegister("127.0.0.3", port, 0x12345678, "bad magic", 8988);
            rawRegister("127.0.0.4", port, Registry.MAGIC, "bad port", 0);
            rawRegister("127.0.0.5", port, Registry.MAGIC, "bad port", 70000);
            try (Socket s = new Socket("127.0.0.1", port)) { s.getOutputStream().write(new byte[]{1, 2, 3}); s.shutdownOutput(); s.setSoTimeout(3000); s.getInputStream().read(); }
            check(reg.devices().size() == before, "bad registrations ignored");
            // the list has a size limit
            for (int i = 10; i < 30; i++) rawRegister("127.0.0." + i, port, Registry.MAGIC, "phone" + i, 8988);
            check(reg.devices().size() == Registry.MAX_DEVICES, "list limited to " + Registry.MAX_DEVICES + ", got " + reg.devices().size());
            // phones that stop announcing disappear
            long old = Registry.freshNanos;
            Registry.freshNanos = 400_000_000L;
            Thread.sleep(700);
            check(reg.devices().isEmpty(), "stale devices disappear");
            Registry.freshNanos = old;
        } finally { reg.stop(); }
    }

    /** One sender, three phones at the same time, each with its own login and encryption. */
    public static void testGroupSend() throws Exception {
        File src = tmp("src");
        final List<Source> files = new ArrayList<>();
        files.add(new FileSource(makeFile(src, "family-video.mp4", 40 * MB + 3, 1)));
        files.add(new FileSource(makeFile(src, "photos.zip", 7 * MB + 11, 2)));
        files.add(new FileSource(makeFile(src, "notes.txt", 5000, 3)));
        final DirFactory[] facs = new DirFactory[3]; final Receiver[] rxs = new Receiver[3]; final int[] ports = new int[3];
        for (int i = 0; i < 3; i++) { facs[i] = new DirFactory(tmp("rx" + i)); rxs[i] = rx(CODE, facs[i], new Rec()); ports[i] = portOf(rxs[i]); }
        try {
            final List<Throwable> errs = Collections.synchronizedList(new ArrayList<Throwable>());
            List<Thread> th = new ArrayList<>();
            for (int i = 0; i < 3; i++) {
                final int k = i;
                Thread t = new Thread(() -> {
                    try { check(Sender.send("127.0.0.1", ports[k], CODE, files, (d, tt) -> {}, new AtomicBoolean(false), 4).complete, "device " + k + " complete"); }
                    catch (Throwable e) { errs.add(e); }
                });
                th.add(t); t.start();
            }
            for (Thread t : th) t.join();
            check(errs.isEmpty(), "no errors: " + errs);
            for (int i = 0; i < 3; i++)
                for (Source s : files) check(sha(facs[i].out(s.name())).equals(sha(((FileSource) s).f)), "device " + i + " has intact " + s.name());
        } finally { for (Receiver r : rxs) r.stop(); }
    }

    // ---------- runner ----------
    public static void main(String[] args) {
        String[] names = {"testNames", "testNameFuzz", "testKeys", "testCodeDistribution", "testSrp", "testFrameCipher",
                "testTransfer", "testAllFileTypes", "testResume", "testInsufficientStorage", "testManyFilesNeverOverCommitSpace",
                "testAlreadyHave", "testConcurrentSenders", "testCancel", "testWrongCodeAndLockout", "testReplay",
                "testIdleAndConnectionFlood", "testEavesdropperSeesNothing", "testTamperedTraffic",
                "testAuthenticatedHostileMessages", "testMemoryExhaustionGuards", "testFuzzReceiver",
                "testPathTraversalName", "testMaliciousReceiver", "testRegistry", "testGroupSend", "testOddFileNames"};
        int failed = 0;
        for (String n : names) {
            long t0 = System.nanoTime();
            try {
                CoreTests.class.getMethod(n).invoke(null);
                cleanup();
                System.out.printf("PASS  %-36s %5.1fs%n", n, (System.nanoTime() - t0) / 1e9);
            } catch (java.lang.reflect.InvocationTargetException e) {
                cleanup();
                failed++;
                System.out.printf("FAIL  %-36s %s%n", n, e.getCause());
                if (!(e.getCause() instanceof AssertionError)) e.getCause().printStackTrace(System.out);
            } catch (Exception e) { failed++; System.out.println("FAIL  " + n + " " + e); }
        }
        System.out.println(failed == 0 ? "ALL " + names.length + " TESTS PASSED" : failed + " TEST(S) FAILED");
        System.exit(failed == 0 ? 0 : 1);
    }
}
