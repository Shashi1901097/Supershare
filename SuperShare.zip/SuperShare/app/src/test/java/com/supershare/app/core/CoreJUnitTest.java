package com.supershare.app.core;

import org.junit.After;
import org.junit.Test;

/** Runs the plain-JDK tests under Gradle / CI. */
public class CoreJUnitTest {
    @After public void tidy() { CoreTests.cleanup(); }
    @Test public void names() throws Exception { CoreTests.testNames(); }
    @Test public void nameFuzz() throws Exception { CoreTests.testNameFuzz(); }
    @Test public void keys() throws Exception { CoreTests.testKeys(); }
    @Test public void codeDistribution() throws Exception { CoreTests.testCodeDistribution(); }
    @Test public void srp() throws Exception { CoreTests.testSrp(); }
    @Test public void frameCipher() throws Exception { CoreTests.testFrameCipher(); }
    @Test public void transfer() throws Exception { CoreTests.testTransfer(); }
    @Test public void allFileTypes() throws Exception { CoreTests.testAllFileTypes(); }
    @Test public void resume() throws Exception { CoreTests.testResume(); }
    @Test public void insufficientStorage() throws Exception { CoreTests.testInsufficientStorage(); }
    @Test public void manyFilesNeverOverCommitSpace() throws Exception { CoreTests.testManyFilesNeverOverCommitSpace(); }
    @Test public void alreadyHave() throws Exception { CoreTests.testAlreadyHave(); }
    @Test public void concurrentSenders() throws Exception { CoreTests.testConcurrentSenders(); }
    @Test public void cancel() throws Exception { CoreTests.testCancel(); }
    @Test public void wrongCodeAndLockout() throws Exception { CoreTests.testWrongCodeAndLockout(); }
    @Test public void replay() throws Exception { CoreTests.testReplay(); }
    @Test public void idleAndConnectionFlood() throws Exception { CoreTests.testIdleAndConnectionFlood(); }
    @Test public void eavesdropperSeesNothing() throws Exception { CoreTests.testEavesdropperSeesNothing(); }
    @Test public void tamperedTraffic() throws Exception { CoreTests.testTamperedTraffic(); }
    @Test public void authenticatedHostileMessages() throws Exception { CoreTests.testAuthenticatedHostileMessages(); }
    @Test public void memoryExhaustionGuards() throws Exception { CoreTests.testMemoryExhaustionGuards(); }
    @Test public void fuzzReceiver() throws Exception { CoreTests.testFuzzReceiver(); }
    @Test public void pathTraversalName() throws Exception { CoreTests.testPathTraversalName(); }
    @Test public void maliciousReceiver() throws Exception { CoreTests.testMaliciousReceiver(); }
    @Test public void registry() throws Exception { CoreTests.testRegistry(); }
    @Test public void groupSend() throws Exception { CoreTests.testGroupSend(); }
    @Test public void oddFileNames() throws Exception { CoreTests.testOddFileNames(); }
}
