package com.supershare.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------------------------------------
// Brand colours (taken from the logo) and the few gradients the app uses.
// ---------------------------------------------------------------------------------------------

val BrandBlue = Color(0xFF4F7CFF)
val BrandViolet = Color(0xFF9B6BFF)
val BrandTeal = Color(0xFF20D6C2)
val BrandDeep = Color(0xFF101B3D)

/** Shared aurora gradients used by primary actions and highlights. */
val BrandBrush = Brush.linearGradient(
    colors = listOf(Color(0xFF4776FF), Color(0xFF765BFF), Color(0xFFB45CFF)),
    start = Offset.Zero, end = Offset(900f, 700f)
)
private val HeroBrush = Brush.linearGradient(
    colors = listOf(Color(0xFF101A38), Color(0xFF253F86), Color(0xFF6347B8), Color(0xFF246F9B)),
    start = Offset.Zero, end = Offset(1100f, 900f)
)
private val HeaderBrush = Brush.horizontalGradient(
    colors = listOf(Color(0xFF17264F), Color(0xFF3157A8), Color(0xFF6549B5))
)

private val BrandDark = darkColorScheme(
    primary = Color(0xFF9CB8FF), onPrimary = Color(0xFF10265E),
    primaryContainer = Color(0xFF294B9B), onPrimaryContainer = Color(0xFFE0E9FF),
    secondary = Color(0xFF8DEDE0), onSecondary = Color(0xFF003731),
    secondaryContainer = Color(0xFF15534D), onSecondaryContainer = Color(0xFFB4F5EB),
    tertiary = Color(0xFFC5A7FF), onTertiary = Color(0xFF32116D),
    tertiaryContainer = Color(0xFF4A2C83), onTertiaryContainer = Color(0xFFEBDDFF),
    error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A), onErrorContainer = Color(0xFFFFDAD6),
    background = Color(0xFF090F1D), onBackground = Color(0xFFEAF0FF),
    surface = Color(0xFF0D1526), onSurface = Color(0xFFEAF0FF),
    surfaceVariant = Color(0xFF26334B), onSurfaceVariant = Color(0xFFB5C2DA),
    outline = Color(0xFF687A9B), outlineVariant = Color(0xFF2A3852),
    surfaceContainerLowest = Color(0xFF080D18), surfaceContainerLow = Color(0xFF111C30),
    surfaceContainer = Color(0xFF16233A), surfaceContainerHigh = Color(0xFF1D2D48),
    surfaceContainerHighest = Color(0xFF263854)
)

private val BrandLight = lightColorScheme(
    primary = Color(0xFF315DCE), onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFDCE5FF), onPrimaryContainer = Color(0xFF10265E),
    secondary = Color(0xFF087F78), onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFB8F2E9), onSecondaryContainer = Color(0xFF002F2B),
    tertiary = Color(0xFF7044B5), onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFEBDDFF), onTertiaryContainer = Color(0xFF2A075F),
    error = Color(0xFFBA1A1A), onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6), onErrorContainer = Color(0xFF410002),
    background = Color(0xFFF3F6FC), onBackground = Color(0xFF111B2D),
    surface = Color(0xFFF8FAFF), onSurface = Color(0xFF111B2D),
    surfaceVariant = Color(0xFFE2E9F5), onSurfaceVariant = Color(0xFF46546B),
    outline = Color(0xFF7787A1), outlineVariant = Color(0xFFD3DDED),
    surfaceContainerLowest = Color(0xFFFFFFFF), surfaceContainerLow = Color(0xFFF0F4FB),
    surfaceContainer = Color(0xFFE9EFF8), surfaceContainerHigh = Color(0xFFE1E9F5),
    surfaceContainerHighest = Color(0xFFD8E2F1)
)

@Composable
fun SuperTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) BrandDark else BrandLight, content = content)
}

fun fmtSize(b: Long): String {
    val u = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = 0
    while (v >= 1024 && i < 4) { v /= 1024; i++ }
    return if (i == 0) "$b B" else "%.1f %s".format(v, u[i])
}

fun fmtEta(s: Long): String = when {
    s < 0 -> "—"
    s < 60 -> "${s}s"
    else -> "${s / 60}m ${s % 60}s"
}

// ---------------------------------------------------------------------------------------------
// Page structure: a coloured header on top, content below
// ---------------------------------------------------------------------------------------------

@Composable
fun Screen(header: @Composable () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            header()
            Column(Modifier.fillMaxSize().navigationBarsPadding().padding(horizontal = 20.dp), content = content)
        }
    }
}

/** Small vector icons drawn directly, so the app needs no icon library. */
@Composable
fun AppIcon(kind: String, tint: Color, size: Dp = 24.dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        val w = s * 0.09f
        val st = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(x: Float, y: Float) = Offset(x * s, y * s)
        when (kind) {
            "up" -> {
                drawLine(tint, p(0.5f, 0.82f), p(0.5f, 0.18f), w, StrokeCap.Round)
                drawLine(tint, p(0.5f, 0.18f), p(0.24f, 0.44f), w, StrokeCap.Round)
                drawLine(tint, p(0.5f, 0.18f), p(0.76f, 0.44f), w, StrokeCap.Round)
            }
            "down" -> {
                drawLine(tint, p(0.5f, 0.18f), p(0.5f, 0.82f), w, StrokeCap.Round)
                drawLine(tint, p(0.5f, 0.82f), p(0.24f, 0.56f), w, StrokeCap.Round)
                drawLine(tint, p(0.5f, 0.82f), p(0.76f, 0.56f), w, StrokeCap.Round)
            }
            "back" -> drawPath(Path().apply { moveTo(0.62f * s, 0.2f * s); lineTo(0.34f * s, 0.5f * s); lineTo(0.62f * s, 0.8f * s) }, tint, style = st)
            "forward" -> drawPath(Path().apply { moveTo(0.38f * s, 0.2f * s); lineTo(0.66f * s, 0.5f * s); lineTo(0.38f * s, 0.8f * s) }, tint, style = st)
            "check" -> drawPath(Path().apply { moveTo(0.2f * s, 0.55f * s); lineTo(0.42f * s, 0.75f * s); lineTo(0.8f * s, 0.28f * s) }, tint, style = st)
            "folder" -> drawRoundRect(tint, topLeft = p(0.1f, 0.24f), size = Size(0.8f * s, 0.58f * s), cornerRadius = CornerRadius(0.08f * s), style = st)
            else -> drawRoundRect(tint, topLeft = p(0.22f, 0.12f), size = Size(0.56f * s, 0.76f * s), cornerRadius = CornerRadius(0.08f * s), style = st)
        }
    }
}

/** The app icon on its own dark tile (the ring has a light centre that needs a dark background). */
@Composable
fun LogoTile(dim: Dp) {
    Box(Modifier.size(dim).shadow(10.dp, RoundedCornerShape(dim * 0.24f)).clip(RoundedCornerShape(dim * 0.24f)).background(Color(0xFF161635)),
        contentAlignment = Alignment.Center) {
        Image(painter = painterResource(R.drawable.logo_ring), contentDescription = "Super Share logo",
            contentScale = ContentScale.Fit, modifier = Modifier.size(dim * 0.78f))
    }
}

/** Big header of the home screen. */
@Composable
fun Hero() {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp)).background(HeroBrush)
        .statusBarsPadding().padding(horizontal = 24.dp, vertical = 24.dp)) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            LogoTile(88.dp)
            Spacer(Modifier.height(14.dp))
            Text("Super Share", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text("Connecting Family And Friends Easily Together", color = Color.White.copy(alpha = 0.82f),
                style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        }
    }
}

/** Header of every other screen: back arrow and title on the brand colour. */
@Composable
fun Header(title: String, onBack: () -> Unit) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(bottomStart = 26.dp, bottomEnd = 26.dp)).background(HeaderBrush)
        .statusBarsPadding().padding(start = 4.dp, end = 20.dp, top = 4.dp, bottom = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { AppIcon("back", Color.White) }
            Text(title, color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Controls
// ---------------------------------------------------------------------------------------------

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceContainer).padding(4.dp)) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(12.dp))
                    .then(if (on) Modifier.background(BrandBrush) else Modifier)
                    .clickable { if (!on) onSelect(i) },
                contentAlignment = Alignment.Center
            ) {
                Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Medium,
                    color = if (on) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier.fillMaxWidth().height(54.dp).alpha(if (enabled) 1f else 0.38f)
            .shadow(if (enabled) 6.dp else 0.dp, shape).clip(shape).background(BrandBrush)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun DangerButton(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier.fillMaxWidth().height(54.dp).shadow(6.dp, shape).clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFFD93B3B), Color(0xFFB3261E)))).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun SmallButton(text: String, danger: Boolean = false, onClick: () -> Unit) {
    FilledTonalButton(
        onClick = onClick, modifier = Modifier.height(36.dp), contentPadding = PaddingValues(horizontal = 14.dp),
        colors = if (danger) ButtonDefaults.filledTonalButtonColors(
            containerColor = MaterialTheme.colorScheme.errorContainer, contentColor = MaterialTheme.colorScheme.onErrorContainer)
        else ButtonDefaults.filledTonalButtonColors()
    ) { Text(text, style = MaterialTheme.typography.labelMedium) }
}

@Composable
fun SurfaceCard(modifier: Modifier = Modifier, horizontalAlignment: Alignment.Horizontal = Alignment.Start,
                content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(16.dp), horizontalAlignment = horizontalAlignment, content = content)
    }
}

@Composable
fun ActionTile(title: String, icon: String, brush: Brush, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Box(modifier.shadow(8.dp, shape).clip(shape).background(brush).clickable(onClick = onClick).padding(20.dp)) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Box(Modifier.size(52.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                AppIcon(icon, Color.White, 28.dp)
            }
            Text(title, color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = modifier)
}

/** The six digits of a code, one box each. */
@Composable
fun CodeDigits(code: String) {
    val digits = code.filter { it.isDigit() }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        digits.forEachIndexed { i, ch ->
            if (i == 3) Spacer(Modifier.width(6.dp))
            Box(Modifier.size(width = 44.dp, height = 58.dp).clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh), contentAlignment = Alignment.Center) {
                Text(ch.toString(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

/** The one place to choose files: a dashed drop-zone style card. */
@Composable
fun BrowseCard(chosen: Int, onClick: () -> Unit) {
    val line = MaterialTheme.colorScheme.outline
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).clickable(onClick = onClick)
            .drawBehind {
                drawRoundRect(line, cornerRadius = CornerRadius(20.dp.toPx()),
                    style = Stroke(width = 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 14f))))
            }.padding(vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(BrandBrush), contentAlignment = Alignment.Center) {
            AppIcon("folder", Color.White, 26.dp)
        }
        Spacer(Modifier.height(8.dp))
        Text("Browse files", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text(if (chosen > 0) "Tap to add more" else "Choose what to send", style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Round progress with a gradient arc; the speed sits in the middle. */
@Composable
fun Gauge(ui: UiState, dim: Dp) {
    val prog by animateFloatAsState(ui.progress, label = "progress")
    val track = MaterialTheme.colorScheme.surfaceContainerHighest
    Box(Modifier.size(dim), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 14.dp.toPx()
            val d = this.size.minDimension - sw
            val tl = Offset(sw / 2, sw / 2)
            drawArc(track, 0f, 360f, false, tl, Size(d, d), style = Stroke(sw))
            rotate(-90f) {
                drawArc(Brush.sweepGradient(listOf(BrandBlue, BrandViolet, BrandBlue)), 0f, 360f * prog, false, tl, Size(d, d),
                    style = Stroke(sw, cap = StrokeCap.Round))
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("%.0f".format(ui.mbps), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.SemiBold)
            Text("Mbps", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Text("%.1f MB/s".format(ui.mbps / 8), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun StatColumn(label: String, value: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun Stats(ui: UiState) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 8.dp)) {
            StatColumn("Transferred", "${fmtSize(ui.done)} / ${fmtSize(ui.total)}", Modifier.weight(1.5f))
            StatColumn("Time left", fmtEta(ui.eta), Modifier.weight(1f))
            StatColumn("Peak", "%.0f Mbps".format(ui.peak), Modifier.weight(1f))
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Files and phones
// ---------------------------------------------------------------------------------------------

/** Colour per kind of file, like a file manager. */
fun typeColor(ext: String): Color = when (ext.lowercase()) {
    "apk", "aab", "xapk" -> Color(0xFF2E9E5B)
    "zip", "rar", "7z", "gz", "tar", "tgz", "bz2", "xz" -> Color(0xFFE08A1E)
    "pdf" -> Color(0xFFD64545)
    "doc", "docx", "txt", "rtf", "odt" -> Color(0xFF2F6BFF)
    "xls", "xlsx", "csv", "ods" -> Color(0xFF1F9D6B)
    "ppt", "pptx" -> Color(0xFFE2582D)
    "mp4", "mkv", "avi", "mov", "webm", "3gp" -> Color(0xFF7A4DF0)
    "mp3", "flac", "wav", "aac", "ogg", "m4a" -> Color(0xFFE0489B)
    "jpg", "jpeg", "png", "gif", "webp", "heic", "bmp" -> Color(0xFF12A5B8)
    else -> Color(0xFF6B7385)
}

@Composable
fun FileBadge(name: String, folder: Boolean = false) {
    val ext = if (folder) "" else name.substringAfterLast('.', "").take(4)
    val base = if (folder) Color(0xFFF2B01E) else typeColor(ext)
    Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp))
        .background(Brush.verticalGradient(listOf(base, base.copy(alpha = 0.78f)))), contentAlignment = Alignment.Center) {
        if (folder) AppIcon("folder", Color.White, 22.dp)
        else Text(ext.uppercase().ifEmpty { "FILE" }, style = MaterialTheme.typography.labelSmall, color = Color.White,
            fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun Avatar(name: String) {
    Box(Modifier.size(42.dp).clip(CircleShape).background(BrandBrush), contentAlignment = Alignment.Center) {
        Text(name.trim().take(1).uppercase().ifEmpty { "?" }, color = Color.White, fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun FileRow(name: String, sub: String, modifier: Modifier = Modifier, trailing: @Composable () -> Unit = {}) {
    ListItem(
        modifier = modifier,
        headlineContent = { Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = { Text(sub) },
        leadingContent = { FileBadge(name) },
        trailingContent = trailing,
        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
    )
}
